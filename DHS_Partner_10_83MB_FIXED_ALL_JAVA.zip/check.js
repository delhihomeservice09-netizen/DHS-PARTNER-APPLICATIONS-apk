







const firebaseConfig={"apiKey":"AIzaSyDySwVvKkMdVDfQZEWO4wPl7tPThrlmnqQ","authDomain":"dhs-delhi-home-service.firebaseapp.com","projectId":"dhs-delhi-home-service","storageBucket":"dhs-delhi-home-service.firebasestorage.app","messagingSenderId":"729497010980","appId":"1:729497010980:web:c861571c0192464fb329b1","measurementId":"G-7FJ4PVLR4Z"};
firebase.initializeApp(firebaseConfig);
window.__dhsAppReady=false;
const auth=firebase.auth(),db=firebase.firestore(),storage=firebase.storage();
let user=null,profile=null,jobs=[],payments=[],unsubs=[],online=false,currentPage='home',fcmToken='';
const esc=x=>String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const first=(o,ks,d='')=>{for(const k of ks)if(o&&o[k]!=null&&o[k]!=='')return o[k];return d};
const ts=v=>v?.toMillis?v.toMillis():v?.seconds?v.seconds*1000:new Date(v||0).getTime();
const money=n=>'₹'+Number(n||0).toLocaleString('en-IN');
const fmt=v=>{let d=v?.toDate?v.toDate():new Date(v);return isNaN(d)?'':d.toLocaleString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})};
function splash(){if(document.getElementById('splash'))return;document.body.insertAdjacentHTML('afterbegin','<div class="splash" id="splash"><img class="splashPoster" src="images/dhs-partner-splash.png" alt="DHS Partner Welcome"><div class="splashShade"></div><div class="splashLoader" aria-label="Loading"><span class="loaderRing"></span><span class="loaderText">Loading...</span></div></div>');setTimeout(()=>document.getElementById('splash')?.remove(),7000)}
splash();
function login(){document.getElementById("root").innerHTML=`<div class="login"><div class="toolsOrbitBg"></div><div class="loginbox glass"><div class="brand"><span class="d">D</span><span class="h">H</span><span class="d">S</span></div><div class="tag">DHS PARTNER LOGIN</div><label>Email</label><input id="email" type="email" autocomplete="username" placeholder="Enter email address"><label>Password</label><input id="pass" type="password" autocomplete="current-password" placeholder="Enter password" onkeydown="if(event.key==='Enter')signIn()"><div class="loginActions"><button class="btn primary full" onclick="signIn()">Login</button><button class="btn orange full" onclick="registerPage()">New Registration</button></div><p id="err" class="dangerText"></p><div class="loginHint">Only approved DHS Partners can enter the Partner App.</div></div></div>`}
function registerPage(){document.getElementById("root").innerHTML=`<div class="login"><div class="loginbox glass"><div class="brand"><span class="d">D</span><span class="h">H</span><span class="d">S</span></div><div class="tag">NEW DHS PARTNER REGISTRATION</div>
<label>Full Name *</label><input id="rn" placeholder="Enter full name" autocomplete="name"><label>Skill / Service *</label><input id="rs" placeholder="Plumber / Electrician / AC etc." autocomplete="organization-title"><label>Mobile Number *</label><input id="rp" inputmode="tel" maxlength="10" placeholder="10 digit mobile number" autocomplete="tel"><label>Email *</label><input id="re" type="email" placeholder="Email address" autocomplete="email"><label>Create Password *</label><input id="rpass" type="password" minlength="6" placeholder="Create login password (min 6 characters)" autocomplete="new-password"><label>Address *</label><textarea id="ra" rows="2" placeholder="Full address"></textarea>
<label>Aadhaar Card Number *</label><input id="ran" inputmode="numeric" maxlength="12" placeholder="12 digit Aadhaar number"><label>PAN Card Number *</label><input id="rpn" maxlength="10" style="text-transform:uppercase" placeholder="PAN number">
<div class="loginHint" style="margin:8px 0">Aadhaar/PAN photos and selfie are not required during registration. DHS Admin can request documents separately.</div>
<button class="btn orange full mt8" onclick="registerPartner()">Submit Registration</button><button class="btn white full mt8" onclick="login()">Back to Login</button><p id="regErr" class="dangerText"></p><div class="loginHint">After submission, this app will remain on the DHS document-check waiting screen until Admin approves you.</div></div></div>`} 
async function uploadFile(file,uid,label){
 if(!file)return '';
 if(!storage) throw Error('Firebase Storage is not initialized');
 const safeName=String(file.name||'file').replace(/[^\w.\-]+/g,'_');
 const path=(String(label).startsWith('work_')?'partnerWorkProofs/':'partnerRegistrations/')+uid+'/'+label+'_'+Date.now()+'_'+safeName;
 const ref=storage.ref(path);const metadata={contentType:file.type||'application/octet-stream',customMetadata:{uploadedBy:uid,uploadType:String(label)}};
 const btn=document.getElementById('uploadCompleteBtn');
 return await new Promise((resolve,reject)=>{let settled=false;const fail=err=>{if(settled)return;settled=true;clearTimeout(timer);let msg=err?.message||String(err)||'Upload failed';if(err?.code==='storage/unauthorized')msg='Firebase Storage permission denied. Check Storage Rules.';reject(Error(msg))};const timer=setTimeout(()=>fail(Error('Upload timed out after 90 seconds.')),90000);const task=ref.put(file,metadata);task.on('state_changed',snap=>{if(btn){let kind=String(label).startsWith('work_video')?'video':'photo';btn.textContent='Uploading '+kind+' '+(snap.totalBytes?Math.round(snap.bytesTransferred/snap.totalBytes*100):0)+'%…'}},fail,async()=>{try{let url=await ref.getDownloadURL();if(settled)return;settled=true;clearTimeout(timer);resolve(url)}catch(e){fail(e)}})})
}
async function registerPartner(){try{
 const name=document.getElementById('rn')?.value.trim(),skill=document.getElementById('rs')?.value.trim(),phone=document.getElementById('rp')?.value.trim(),email=document.getElementById('re')?.value.trim().toLowerCase(),pass=document.getElementById('rpass')?.value,address=document.getElementById('ra')?.value.trim(),aadhaarNumber=document.getElementById('ran')?.value.trim(),panNumber=document.getElementById('rpn')?.value.trim().toUpperCase();
 if(!name||!skill||!phone||!email||!pass||!address||!aadhaarNumber||!panNumber)throw Error('Please fill all required details');
 if(!/^\d{10}$/.test(phone))throw Error('Please enter a valid 10 digit mobile number');
 if(!/^\d{12}$/.test(aadhaarNumber))throw Error('Please enter a valid 12 digit Aadhaar number');
 if(!/^[A-Z]{5}\d{4}[A-Z]$/.test(panNumber))throw Error('Please enter a valid PAN number');
 if(pass.length<6)throw Error('Password must be at least 6 characters');
 let cred;try{cred=await auth.createUserWithEmailAndPassword(email,pass)}catch(authErr){if(authErr.code==='auth/email-already-in-use'){cred=await auth.signInWithEmailAndPassword(email,pass)}else throw authErr} const uid=cred.user.uid;
 const now=firebase.firestore.FieldValue.serverTimestamp();
 const data={uid,name,skill,phone,email,address,aadhaarNumber,panNumber,aadhaarFront:'',aadhaarBack:'',panFront:'',panBack:'',aadhaar:'',pan:'',selfie:'',documentsRequired:false,status:'PENDING_REVIEW',partnerStatus:'PENDING_REVIEW',registrationStatus:'PENDING_REVIEW',adminReviewStatus:'PENDING',approved:false,documentStatus:'PENDING_REVIEW',applicationType:'NEW_PARTNER_REGISTRATION',sentToAdmin:true,createdAt:now,updatedAt:now};
 await db.collection('partnerRegistrations').doc(uid).set(data,{merge:true});
 // Mirror the same application for Admin builds that use partnerApplications.
 try{await db.collection('partnerApplications').doc(uid).set({...data,sourceCollection:'partnerRegistrations'},{merge:true})}catch(e){console.warn('partnerApplications mirror skipped:',e)}
 showWaiting(email,uid);
}catch(e){document.querySelector('#regErr')?.remove();let x=document.createElement('p');x.id='regErr';x.className='dangerText';x.textContent=e.code==='auth/email-already-in-use'?'This email is already registered. Please use Login.':(e.message||'Registration failed');document.querySelector('.loginbox')?.appendChild(x)}}
function showWaiting(email='',uid=user?.uid){document.getElementById("root").innerHTML=`<div class="registrationWait"><div class="waitbox"><div class="waitBrand"><span>D</span><b>H</b><span>S</span></div><div class="waitPulse"><div class="waitSpinner"></div></div><div class="waitTitle">Welcome DHS Partner</div><p class="waitSub">Waiting for approval</p><p class="waitEmail">${esc(email)}</p><p class="waitCopy">DHS Admin is checking your registration details and documents. Please keep this page open. It will automatically continue when Admin approves your partner registration.</p><div class="waitProgress"><i></i></div><span class="waitLock">🔒 Secure DHS Partner verification</span></div></div>`;if(uid)listenRegistrationApproval(uid)}
let registrationApprovalUnsub=null,workerApprovalUnsub=null,applicationApprovalUnsub=null;
function listenRegistrationApproval(uid){
 registrationApprovalUnsub?.();workerApprovalUnsub?.();applicationApprovalUnsub?.();
 const approved=async d=>{let st=String(d?.status||d?.partnerStatus||d?.registrationStatus||'').toUpperCase();if(d&&(d.approved===true||['APPROVED','JOINED','ACTIVE'].includes(st))){registrationApprovalUnsub?.();workerApprovalUnsub?.();applicationApprovalUnsub?.();registrationApprovalUnsub=workerApprovalUnsub=applicationApprovalUnsub=null;await gate(auth.currentUser||user)}else if(st==='REJECTED'){let p=document.querySelector('.registrationWait .waitSub');if(p)p.innerHTML='<b style="color:#dc2626">Registration rejected by Admin.</b>';}};
 registrationApprovalUnsub=db.collection('partnerRegistrations').doc(uid).onSnapshot(snap=>{if(snap.exists)approved(snap.data())},e=>console.warn('registration approval listener',e));
 applicationApprovalUnsub=db.collection('partnerApplications').doc(uid).onSnapshot(snap=>{if(snap.exists)approved(snap.data())},()=>{});
 workerApprovalUnsub=db.collection('workers').doc(uid).onSnapshot(snap=>{if(snap.exists)approved(snap.data())},()=>{});
}
async function signIn(){
 try{
  const email=document.querySelector('#email')?.value.trim(),pass=document.querySelector('#pass')?.value;
  if(!email||!pass) throw new Error('Email and password required');
  document.getElementById('signinPop')?.remove();
  const pop=document.createElement('div');pop.id='signinPop';pop.className='notificationPop';pop.innerHTML='<h3>Signing in…</h3><p>Checking DHS Partner account</p>';document.body.appendChild(pop);
  await auth.signInWithEmailAndPassword(email,pass);
 }catch(e){document.getElementById('signinPop')?.remove();const el=document.querySelector('#err');if(el)el.textContent=e.message||'Login failed';}
}
function shell(){closeModal?.();document.getElementById("root").innerHTML=`<div class="app"><header class="top"><div class="logo dhsPartnerTopLogo"><span>D</span><span>H</span><span class="h">S</span><em>PARTNER</em></div><div class="topActions"><button id="topActionBtn" class="glassIcon" onclick="openNotifications(event);return false" aria-label="New Leads" title="New Leads"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 13.5V11a8 8 0 0 1 16 0v2.5l1.2 2.1H2.8L4 13.5Z"/><path d="M9.5 19a3 3 0 0 0 5 0"/><path d="M12 3v1"/></svg><span id="leadBadge" class="leadBellBadge" style="display:none">0</span></button></div></header>
<main class="page">
<section id="home" class="screen active"><div class="hero"><img class="avatar" id="heroPic" src="worker.png"><div class="grow"><h2 id="heroName">DHS Partner</h2><small id="heroSkill">Partner</small><div class="onlineRow"><span>Offline</span><button id="onlineSwitch" class="switch" onclick="toggleOnline()"><i></i></button><span>Online</span></div></div></div>
<div class="mapCard" id="mapCard"><div class="mapHead"><button class="mapBack" id="mapBackBtn" onclick="closeLiveMap()" aria-label="Back">‹</button><b>D<span>H</span>S <small style="font-size:10px;letter-spacing:3px">PARTNER</small></b><span class="badge ok" id="mapStatus">LIVE</span></div><div class="map homeLiveMap partnerMapShell idleWaiting" id="homeMap">
<iframe id="routeMapFallback" title="Customer map" aria-hidden="true" loading="eager" referrerpolicy="no-referrer-when-downgrade"></iframe>
<div id="routeLeafletMap" aria-label="DHS Partner road route map"></div>
<div class="routeMapFallbackOverlay" aria-hidden="true"><div class="fallbackRoad r1"></div><div class="fallbackRoad r2"></div><div class="fallbackRoad r3"></div><div class="fallbackRoute"></div><div class="fallbackPin me">➤</div><div class="fallbackPin customer">●</div></div>
<div class="partnerMapOverlay">
  <div class="idleEarningState" id="idleEarningState">
    <div class="idleOfflineCreator" id="idleOfflineCreator">
      <img src="images/dhs-creator.png" alt="DHS Partner" loading="eager">
      <div class="idleOfflineCreatorText">Go Online Partner</div>
    </div>
    <div class="idleOnlineState" id="idleOnlineState">
      <div class="idleToolsOrbit" id="idleToolsOrbit" aria-hidden="true"><img src="images/dhs-tools-orbit.png" alt="" loading="eager"><div class="idleOrbitCenter" aria-hidden="true"><span class="d">D</span><span class="h">H</span><span class="s">S</span></div></div>
      <div class="idleOnlineEarn">START EARNING</div>
      <div class="idleOnlineWaiting">Waiting for bookings<span class="waitingDots"><i></i><i></i><i></i></span></div>
    </div>
  </div>
  <div class="partnerMapTop">
    <div class="partnerPerson">
      <div class="role">● Customer</div>
      <b id="mapCustomerName">Customer</b>
      <small id="mapCustomerAddress">Customer location</small>
    </div>
    <div class="partnerDistance"><strong id="mapDistance">—</strong><span>distance</span></div>
    <div class="partnerPerson right">
      <div class="role">● Partner (You)</div>
      <b id="mapPartnerName">DHS Partner</b>
      <small id="mapPartnerAddress">Your location</small>
    </div>
  </div>
  <div class="routeNavBanner" id="routeNavBanner"><div class="routeNavArrow"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 4 16 8-16 8 3.7-8L4 4Z"/></svg></div><div class="routeNavText"><div class="routeNavDistance" id="routeNavDistance">— km</div><div class="routeNavStreet" id="routeNavStreet">Customer Route</div><div class="routeNavSub">Follow the route to customer</div></div></div>
  <div class="routeActionPanel" id="routeActionPanel">
    <div class="routeActionRow">
      <a class="routeActionBtn call" id="routeCallBtn" href="tel:" aria-label="Call Customer">
        <span class="routeSvgIcon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.7.6 2.5a2 2 0 0 1-.5 2.1L8 9.6a16 16 0 0 0 6.4 6.4l1.3-1.2a2 2 0 0 0 2.1-.5c.8.3 1.6.5 2.5.6A2 2 0 0 1 22 16.9Z"/></svg></span><span>Call Customer</span><small>Tap to call</small>
      </a>
      <button class="routeActionBtn nav" id="routeNavigateBtn" onclick="navigateToCustomer()" aria-label="Navigate to Customer">
        <span class="routeSvgIcon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 3 18 9-18 9 4-9-4-9Z"/><path d="M7 12h14"/></svg></span><span>Navigate</span><small>Open in Maps</small>
      </button>
    </div>
    <div class="routeTripCard" id="routeTripCard"><div class="routeTripMain" id="routeTripMain">— min · — km</div><div class="routeTripSub" id="routeTripSub">Going to customer</div><div class="routeRoadNames" id="routeRoadNames"></div></div>
    <button class="routeCompleteBtn startJobBtn" id="routeCompleteBtn" onclick="startJob(activeRouteJob?.id)"><span class="startJobIcon">▶</span> Start Job</button>
  </div>
  <div class="partnerBookingRequest" id="partnerBookingRequest">
    <div class="partnerBookingRequestHead"><span class="requestTitle">NEW BOOKING</span><span class="requestTimer" id="requestTimer">15s</span></div>
    <div class="partnerBookingRequestBody"><b id="requestCustomerName">Customer</b><div class="requestService" id="requestService">Service</div><div class="requestDistance" id="requestDistance">4 min · 4.1 km away</div></div>
    <button class="requestAccept" id="requestAcceptBtn">Accept</button>
  </div>
  <div class="partnerMapTools">
    <button class="mapTool" onclick="toggleMapMode()" id="mapModeBtn">3D</button>
    <button class="mapTool" onclick="centerPartnerMap()" aria-label="My Location">⌾</button>
    <button class="mapTool mapCompass" onclick="centerPartnerMap()" aria-label="Compass">🧭</button>
  </div>
  <div class="partnerMapJobCard"><b id="mapService">Waiting for assigned job</b><span class="partnerMapStatus" id="mapLiveStatus">LIVE</span><small id="mapNote">Accept a new booking to start live navigation.</small></div>
  <div class="partnerMapBottom routeLegacyActions">
    <button class="mapAction call" id="mapCallBtn" onclick="callActiveCustomer()"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.7.6 2.5a2 2 0 0 1-.5 2.1L8 9.6a16 16 0 0 0 6.4 6.4l1.3-1.2a2 2 0 0 0 2.1-.5c.8.3 1.6.5 2.5.6A2 2 0 0 1 22 16.9Z"/></svg><span>Call Customer</span></button>
    <button class="mapAction nav" onclick="navigateToCustomer()"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 3 18 9-18 9 4-9-4-9Z"/><path d="M7 12h14"/></svg><span>Navigate</span></button>
  </div>
  <div id="arrivalActions" class="arrivalActions" style="display:none"></div>
</div>
</div></div>
<div class="sectionTitle">Live Work Tracking</div><div class="card"><div class="muted">Accept a new booking to open this live customer route. Call and Navigate are available directly on the map.</div></div></section>
<section id="earnings" class="screen"><div class="sectionTitle" data-i18n="earnings">Earnings</div><div class="statgrid"><div class="stat clickable" onclick="openEarningDetail('completed')"><small data-i18n="totalCompleted">Total Jobs Completed</small><strong id="statJobs">0</strong><div class="statAction">Tap to view job details ›</div></div><div class="stat clickable" onclick="openEarningDetail('total')"><small data-i18n="totalEarning">Total Earning</small><strong id="statPay">₹0</strong><div class="statAction">Tap to view earning details ›</div></div><div class="stat clickable" onclick="openEarningDetail('week')"><small data-i18n="weekEarning">This Week Earning</small><strong id="statWeek">₹0</strong><div class="statAction">Tap to view weekly jobs ›</div></div><div class="stat clickable" onclick="openEarningDetail('bills')"><small>Total Bills</small><strong id="statBills">0</strong><div class="statAction">Tap to view all bills ›</div></div></div><div class="walletCard"><div class="walletIcon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H20v14H5.5A2.5 2.5 0 0 1 3 16.5v-9Z"/><path d="M3 8h15.5A2.5 2.5 0 0 1 21 10.5v3H17a2.5 2.5 0 0 1 0-5h4"/><circle cx="17" cy="11" r=".7"/></svg></div><div class="walletText"><b>WALLET (CASH)</b><strong id="walletCashTotal">₹0</strong><span>All Pay Cash / COD payments</span></div><div class="walletBadge">CASH</div></div><div class="paymentCenterCard"><div class="paymentCenterHead"><div><b>UPI QR / COD PAYMENT</b><small>Bill generate hone ke baad customer se payment collect karein</small></div><div class="paymentQrIcon">⌁</div></div><div class="paymentCenterBody"><div class="qrPlaceholder" id="earningsQrPreview"><span>QR</span><small>Pay COD</small></div><div class="paymentCenterInfo"><strong>Pay COD</strong><p>Amount add karein → Pay dabayein → QR dikhayein → customer PhonePe / UPI se scan kare.</p><button class="btn primary full" onclick="openCodPayment()">Pay COD</button></div></div><div class="paymentCenterNote">QR me DHS UPI ID aur selected bill ka exact amount rahega.</div></div><div id="completedList" style="display:none"></div></section>
<section id="bills" class="screen"><div class="sectionTitle">▤ Create Bill</div><div id="billList"></div><button class="btn white full mt8" onclick="resetBill(true);window.scrollTo({top:0,behavior:'smooth'})">＋ New Bill</button>
<div class="bill-editor">
<div class="bill-grid"><div class="bill-field"><label>Customer Name *</label><input id="name"></div><div class="bill-field"><label>Customer Number *</label><input id="phone" type="tel"></div><div class="bill-field"><label>Invoice No.</label><input id="invoiceNo"></div><div class="bill-field"><label>Date</label><input id="date" type="date"></div><div class="bill-field bill-full"><label>Service Address *</label><input id="address"></div><div class="bill-field"><label>Service Type *</label><textarea id="service"></textarea></div></div>
<div class="bill-items-title">WORK / ITEMS</div><div class="bill-item-head"><div>#</div><div>Description *</div><div>Details</div><div>Qty.</div><div>Rate (₹)</div><div>Amount (₹)</div><div>Action</div></div><div id="items"></div><button class="bill-add" onclick="addItem()">＋ Add Item</button><div class="bill-bottom"><div class="bill-field"><label>Notes</label><textarea id="notes" class="bill-notes">• All work has been completed successfully.
• Please ensure payment is made upon completion of service.
• Thank you for choosing Delhi Home Service.</textarea></div><div class="bill-summary"><div class="bill-sumline"><span>Sub Total</span><b id="subtotal">₹0.00</b></div><div class="bill-sumline"><span>Discount</span><input id="discount" type="number" value="0" min="0" oninput="calc()"></div><div class="bill-sumline bill-sumtotal"><span>Total Amount</span><span id="total">₹0.00</span></div><div class="bill-sumline"><span>Payment Status</span><select id="paymentStatus"><option>PAID</option><option>PENDING</option></select></div><div class="bill-sumline"><span>Payment Method</span><select id="paymentMethod"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Razorpay</option></select></div><div class="bill-actions"><button class="bill-generate" onclick="generate()">▣ Generate Bill</button><button class="bill-reset" onclick="resetBill()">Reset</button></div></div></div></div>
<div class="bill-preview-title">INVOICE PREVIEW</div><div class="bill-preview-wrap"><div id="invoice" class="dhs-invoice"><div class="dhs-inv-head"><div><div class="dhs-brand-logo">D H <span>S</span></div><div class="dhs-company">Delhi Home Service</div><div class="dhs-tag">Professional Home Repair Experts</div></div><div class="dhs-inv-meta"><b>Invoice No:</b> <span id="pInvoice"></span><br><b>Date:</b> <span id="pDate"></span></div></div><div class="dhs-section-title">SERVICE INVOICE</div><div class="dhs-info-area"><div class="dhs-customer-info"><div class="dhs-crow"><b>Customer Name</b><span>:</span><span id="pName">—</span></div><div class="dhs-crow"><b>Customer Number</b><span>:</span><span id="pPhone">—</span></div><div class="dhs-crow"><b>Service Address</b><span>:</span><span id="pAddress">—</span></div><div class="dhs-crow"><b>Service Type</b><span>:</span><span id="pService">—</span></div></div><div class="dhs-contact-area"><div class="dhs-review-box"><div style="font-size:12px">Review us on</div><div class="dhs-google"><span>G</span><span>o</span><span>o</span><span>g</span><span>l</span><span>e</span></div><img class="dhs-qr" src="images/review-qr.png" alt="Google Review QR"></div><div class="dhs-contacts"><div class="dhs-contact"><div class="dhs-icon">✉</div><div><b>Email</b>delhihomeservice09@gmail.com</div></div><div class="dhs-contact"><div class="dhs-icon">◎</div><div><b>Website</b>delhihomeservices.netlify.app</div></div><div class="dhs-contact"><div class="dhs-icon">☎</div><div><b>Call / WhatsApp</b>97184 48382</div></div></div></div></div><table class="dhs-table"><thead><tr><th>#</th><th>Description</th><th>Details</th><th>Qty.</th><th>Rate (₹)</th><th>Amount (₹)</th></tr></thead><tbody id="pItems"></tbody></table><div class="dhs-bottom-area"><div class="dhs-notes-area"><h4>Notes:</h4><ul id="pNotes"></ul></div><div class="dhs-signature-area"><div class="dhs-auth">Authorized Signature</div><div class="dhs-company-small">Delhi Home Service</div><img class="dhs-signature-img" src="images/dhs-signature.png" alt="DHS Authorized Signature"><img class="dhs-stamp-img" src="images/dhs-stamp.png" alt="DHS Stamp"></div><div class="dhs-totals"><div class="dhs-tline"><span>Sub Total</span><b id="pSubtotal">₹0.00</b></div><div class="dhs-tline"><span>Discount</span><b id="pDiscount">- ₹0.00</b></div><div class="dhs-ttotal"><span>Total Amount</span><span id="pTotal">₹0.00</span></div><div class="dhs-words" id="pWords">(Rupees Zero Only)</div><div class="dhs-status" id="pStatus">Payment Status: PAID</div></div></div></div><div class="dhs-footer">✓ Verified Professionals <span>|</span> ✓ On Time Service <span>|</span> ✓ Trusted by Customers <span>|</span> ✓ Quality Assured</div></div><div class="bill-preview-actions"><button class="bill-print" onclick="printBill()">🖨 Print / PDF</button><button class="bill-download" onclick="downloadPDF()">⬇ Download PDF</button><button style="background:#0a9d42;color:#fff" onclick="payCash()">💵 Pay Cash</button><button style="background:#6d28d9;color:#fff" onclick="payQR()">▣ Pay QR</button><button class="bill-close" onclick="document.getElementById('invoice')?.scrollIntoView({behavior:'smooth'})">View Bill</button></div></div></section>
<section id="settings" class="screen settingsScreen" style="display:none"></section><section id="profile" class="screen">
<div class="card center profileHeroCard"><img id="profilePic" class="avatar" style="width:92px;height:92px" src="worker.png"><h2 id="profileName">Partner</h2><p id="profileSkill" class="muted">Skill</p><button class="btn white" onclick="editProfile()">Edit Profile</button></div>
<div class="profileSettingsTitle"><b>Settings</b><small>DHS Partner App Settings</small></div>
<div class="settingsCard"><button class="settingsItem help" type="button" onclick="openDhsHelpChat()"><svg viewBox="0 0 24 24"><path d="M20 11.5a7.5 7.5 0 0 1-7.8 7.5 8.6 8.6 0 0 1-3.4-.7L4 20l1.2-3.7A7.2 7.2 0 0 1 4 11.5 7.5 7.5 0 0 1 11.5 4H12a7.5 7.5 0 0 1 8 7.5Z"/><path d="M8 11.5h.01M12 11.5h.01M16 11.5h.01"/></svg><span class="siText"><b>Chat DHS Help Team</b><small>Chat with our support team</small></span><span class="chev">›</span></button></div>
<div class="settingsCard"><button class="settingsItem danger" onclick="openSlideCall('police')"><svg viewBox="0 0 24 24"><path d="M12 3 4 6v5c0 5 3.4 8.8 8 10 4.6-1.2 8-5 8-10V6l-8-3Z"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg><span class="siText"><b data-i18n="callPolice">Call Police</b><small data-i18n="slidePolice">Slide to call emergency police</small></span><span class="chev">›</span></button></div>
<div class="settingsCard"><button class="settingsItem" onclick="openLanguageSettings()"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.2 2.4 3.4 5.4 3.4 9s-1.2 6.6-3.4 9c-2.2 4.6-3.4 6.6-3.4 9S9.8 12 12 3Z"/></svg><span class="siText"><b data-i18n="language">Language</b><small id="languageCurrent">English</small></span><span class="chev">›</span></button></div>
<div class="settingsCard"><button class="settingsItem" onclick="openBankAccount()"><svg viewBox="0 0 24 24"><path d="m3 10 9-6 9 6"/><path d="M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18M2 10h20"/></svg><span class="siText"><b data-i18n="bankAccount">Bank Account</b><small id="bankAccountSummary" data-i18n="addBank">Add your bank account for earnings</small></span><span class="chev">›</span></button></div>
<div class="settingsCard"><div id="resetPasswordAction"></div><button class="settingsItem danger" onclick="resetData()"><svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m19 6-1 15H6L5 6"/><path d="M10 11v6M14 11v6"/></svg><span class="siText"><b data-i18n="resetAll">Reset All Data</b><small data-i18n="resetSub">Password required. Clears DHS Partner app data for this partner.</small></span><span class="chev">›</span></button></div>
<div class="settingsCard"><button class="settingsItem logout" onclick="auth.signOut()"><svg viewBox="0 0 24 24"><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M21 3v18"/></svg><span class="siText"><b data-i18n="logout">Logout</b><small data-i18n="logoutSub">Sign out from DHS Partner</small></span><span class="chev">›</span></button></div>
<div class="card"><p class="dangerText" style="margin:0" data-i18n="resetImportant">Reset removes only this partner's app data. A global reset must be authorized from DHS Admin/Firebase server-side.</p></div>
</section>
</main><nav class="bottom"><button class="active" data-page="home" onclick="go('home',this)"><span>⌂</span>Home</button><button data-page="earnings" onclick="go('earnings',this)"><span>◈</span>Earning</button><button data-page="bills" onclick="newBill()"><span>▣</span>Bill</button><button data-page="profile" onclick="go('profile',this)"><span>◎</span>Profile</button></nav></div>`;renderProfile();renderIdleAvailability();updateTopAction();updateLeadBadge();loadPartnerSettings();listenJobs();listenBills();listenPayments();enableFCM();getLocation();setTimeout(processPushAction,900)}
function updateTopAction(){const b=document.getElementById('topActionBtn');if(!b)return;b.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 13.5V11a8 8 0 0 1 16 0v2.5l1.2 2.1H2.8L4 13.5Z"/><path d="M9.5 19a3 3 0 0 0 5 0"/><path d="M12 3v1"/></svg><span id="leadBadge" class="leadBellBadge" style="display:none">0</span>';b.setAttribute('aria-label','New Leads');b.title='New Leads';b.onclick=(e)=>{try{e.preventDefault();e.stopPropagation()}catch(x){}openNotifications(e)};b.removeAttribute('ontouchend');updateLeadBadge()}
function go(page,btn){
  // Android WebView can keep the old scroll position/focused fixed-nav button when
  // switching display:none screens. Clear focus first, then reset every possible
  // scroll owner after the new screen is visible.
  try{document.activeElement?.blur()}catch(e){}
  currentPage=page;
  document.body.classList.toggle('dhs-profile-open', page==='profile');
  document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));
  const target=document.getElementById(page);
  if(target)target.classList.add('active');
  document.querySelectorAll('.bottom button').forEach(x=>x.classList.remove('active'));
  if(page!=='settings')btn?.classList.add('active');
  if(page==='settings')document.querySelector('[data-page="profile"]')?.classList.add('active');
  if(page==='settings'){go('profile',document.querySelector('[data-page="profile"]'));return;}
  updateTopAction();
  if(page==='earnings')renderEarnings();
  if(page==='bills'){renderBills();window.scrollTo(0,0)}
  const resetScroll=()=>{
    try{document.documentElement.style.overflowAnchor='none';document.body.style.overflowAnchor='none'}catch(e){}
    const scrollers=[document.documentElement,document.body,document.scrollingElement,document.querySelector('.app'),document.querySelector('main.page')];
    scrollers.forEach(el=>{if(el){try{el.scrollTop=0;el.scrollLeft=0}catch(e){}}});
    try{window.scrollTo(0,0)}catch(e){}
    if(page==='profile' && target){try{target.scrollTop=0}catch(e){};try{document.documentElement.scrollTop=0;document.body.scrollTop=0}catch(e){}}
  };
  resetScroll();
  requestAnimationFrame(()=>{resetScroll();requestAnimationFrame(resetScroll)});
  setTimeout(resetScroll,80);
}
function renderProfile(){let p=profile||{};document.querySelector('#heroName').textContent=first(p,['name'],user?.displayName||'DHS Partner');document.querySelector('#heroSkill').textContent=first(p,['skill','service'],'Partner');document.querySelector('#profileName').textContent=first(p,['name'],user?.displayName||'Partner');document.querySelector('#profileSkill').textContent=first(p,['skill','service'],'Skill');let pic=first(p,['profilePhoto','profilePic','selfie','photoURL','photo','imageUrl'],'worker.png');document.querySelector('#heroPic').src=pic;document.querySelector('#profilePic').src=pic;let st=String(p.status||'offline').toLowerCase();online=['online','active','available','working'].includes(st);document.querySelector('#onlineSwitch').classList.toggle('on',online)}
function jobState(j){return String(first(j,['partnerStatus','Stuts','bookingStatus','status'],'PENDING_ACCEPT')).toUpperCase()}
function assignedToMe(d){if(['EXPIRED','REJECTED'].includes(jobState(d)))return false;let email=user?.email?.toLowerCase(),uid=user?.uid;let ids=[d.workeruid,d.workerUid,d.partnerUid,d.partnerId,d.assignedPartnerId,d.assignedTo,d.workerid,d.partnerEmail,d.workeremail,d.assignedEmail,d.workerEmail,d.workerid].map(x=>String(x||'').toLowerCase());return ids.includes(String(uid||'').toLowerCase())||ids.includes(email)}
let leadNotifications=[];
try{leadNotifications=JSON.parse(localStorage.getItem('dhsLeadNotifications')||'[]')}catch(e){leadNotifications=[]}
function leadCreatedDate(j){let v=first(j,['createdAt','sentAt','assignedAt','date','createdDate'],null);if(v?.toDate)return v.toDate();if(v?.seconds)return new Date(v.seconds*1000);let d=new Date(v||Date.now());return isNaN(d)?new Date():d}
function recordLeadNotification(j){if(!j?.id)return;let id=String(j.id);if(leadNotifications.some(x=>x.id===id))return;let customer=first(j,['costumername','customerName','customer'],'Customer'),service=first(j,['service','serviceType'],'Service'),address=first(j,['costumerAddress','customerAddress','address'],'Address not available');leadNotifications.unshift({id,customer,service,address,createdAt:leadCreatedDate(j).toISOString(),status:jobState(j)});leadNotifications=leadNotifications.slice(0,50);try{localStorage.setItem('dhsLeadNotifications',JSON.stringify(leadNotifications))}catch(e){}updateLeadBadge()}
function updateLeadBadge(){const b=document.getElementById('leadBadge');if(!b)return;const live=(jobs||[]).filter(j=>['NEW','PENDING_ACCEPT'].includes(jobState(j))).length;const n=live||leadNotifications.length;b.textContent=n>99?'99+':String(n);b.style.display=n?'grid':'none'}
function formatLeadTime(v){const d=new Date(v);return isNaN(d)?'Time unavailable':d.toLocaleString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit',hour12:true})}

function listenJobs(){
 unsubs.forEach(x=>x());unsubs=[];jobs=[];const seen=new Map();let initialJobWindow=true;setTimeout(()=>initialJobWindow=false,2500);
 const process=(s)=>{s.docChanges().forEach(ch=>{if(ch.type==='removed')seen.delete(ch.doc.id);else{let d={id:ch.doc.id,...ch.doc.data()};if(assignedToMe(d)){const prev=seen.get(ch.doc.id)||{};seen.set(ch.doc.id,{...prev,...d})}}});let oldIds=new Set(jobs.map(x=>x.id));jobs=[...seen.values()].sort((a,b)=>ts(b.createdAt)-ts(a.createdAt));renderJobs();if(!initialJobWindow&&online){jobs.filter(j=>!oldIds.has(j.id)&&['NEW','PENDING_ACCEPT'].includes(jobState(j))).forEach(j=>{recordLeadNotification(j);showNewBookingPopup(j)})}};
 const attach=q=>{try{let u=q.onSnapshot(process,e=>console.warn('job listener',e));unsubs.push(u)}catch(e){console.warn(e)}};
 if(user?.uid){attach(db.collection('partnerJobs').where('workeruid','==',user.uid));attach(db.collection('partnerJobs').where('partnerId','==',user.uid));attach(db.collection('partnerJobs').where('partnerEmail','==',user.email));attach(db.collection('partnerJobs').where('workeremail','==',user.email));attach(db.collection('bookings').where('workeruid','==',user.uid));attach(db.collection('bookings').where('workeremail','==',user.email));}
 setTimeout(()=>{if(!jobs.length){db.collection('partnerJobs').limit(100).get().then(s=>{s.docs.forEach(d=>{let x={id:d.id,...d.data()};if(assignedToMe(x))jobs.push(x)});jobs.sort((a,b)=>ts(b.createdAt)-ts(a.createdAt));renderJobs()}).catch(()=>{})}},1200);setTimeout(()=>{let pending=jobs.find(x=>['PENDING_ACCEPT','NEW'].includes(jobState(x)));if(online&&pending)showNewBookingPopup(pending)},3200);
}
function renderIdleAvailability(){
 const msg=document.getElementById('idleOfflineMessage'),orbit=document.getElementById('idleToolsOrbit'),map=document.getElementById('homeMap');
 if(!map)return;
 map.classList.toggle('onlineState',!!online);
 if(msg)msg.style.display='none';
 if(orbit){orbit.style.display=online?'flex':'none';orbit.classList.toggle('online',!!online);}
}

function setHomeWaitingState(waiting=true){
 const map=document.getElementById('homeMap');
 if(!map)return;
 if(waiting)map.classList.add('idleWaiting');else map.classList.remove('idleWaiting');
}
function renderJobs(){
 const el=document.querySelector('#allJobsList');
 if(el){el.innerHTML='';}
 const badge=document.querySelector('#jobCountBadge');if(badge)badge.textContent='';
 let j=jobs.find(x=>['PENDING_ACCEPT','NEW'].includes(jobState(x)));if(j){setMapJob(j)}
 const active=activeRouteJob&&['ACCEPTED','ON_THE_WAY','WORKING','ARRIVED'].includes(jobState(activeRouteJob));
 if(!active&&!document.querySelector('#homeMap .partnerMapOverlay')?.classList.contains('requestActive'))setHomeWaitingState(true);
}
function jobCard(j){let st=jobState(j),accepted=['ACCEPTED','ON_THE_WAY','WORKING','ARRIVED'].includes(st),customer=first(j,['costumername','customerName','customer'],'Customer'),service=first(j,['service','serviceType'],'Service'),addr=first(j,['costumerAddress','customerAddress','address'],'');return `<div class="card"><div class="row"><div class="grow"><div class="bookingTitle">${esc(customer)}</div><div class="muted">${esc(service)}</div><div class="muted">${esc(addr)}</div></div><span class="badge ${accepted||st==='COMPLETED'?'ok':st==='REJECTED'?'no':''}">${esc(st)}</span></div><div class="actions">${st==='PENDING_ACCEPT'||st==='NEW'?`<button class="btn green" onclick="jobDecision('${j.id}','ACCEPTED')">Accept</button><button class="btn danger" onclick="jobDecision('${j.id}','REJECTED')">Reject</button>`:''}${accepted&&st!=='ARRIVED'?`<button class="btn orange" onclick="startJob('${j.id}')">Start Job</button>`:''}${st==='ARRIVED'?`<button class="btn orange" onclick="startWorkFromMap()">Start Work</button>`:''}<button class="btn white" type="button" onclick="callCustomerByJob('${esc(j.id)}')">📞 Call Customer</button><button class="btn white" onclick="openMapById('${esc(j.id)}')">📍 Map</button></div></div>`}
async function syncPartnerAdmin(extra={}){
 try{
  const c=profile?.collection||'workers',id=profile?.id||user?.uid;
  if(!user||!id)return;
  const patch={uid:user.uid,email:user.email,workeremail:user.email,adminSyncAt:firebase.firestore.FieldValue.serverTimestamp(),...extra};
  await db.collection(c).doc(id).set(patch,{merge:true});
  await db.collection('partnerActivity').add({partnerId:user.uid,workerid:profile?.id||user.uid,partnerName:first(profile,['name'],user.email),partnerEmail:user.email,...extra,createdAt:firebase.firestore.FieldValue.serverTimestamp()});
 }catch(e){console.warn('admin sync failed',e)}
}

let alertLoopTimer=null;
function playAlert(){
 try{
  const a=document.querySelector('#alert');
  if(a){a.currentTime=0;const p=a.play();p?.catch(()=>{});}
  if(navigator.vibrate)navigator.vibrate([500,120,500,120,900,150,700]);
  clearTimeout(alertLoopTimer);
  let count=0;
  alertLoopTimer=setInterval(()=>{
    count++;
    if(navigator.vibrate)navigator.vibrate([450,120,450]);
    if(a){a.currentTime=0;a.play()?.catch(()=>{});}
    if(count>=4){clearInterval(alertLoopTimer);alertLoopTimer=null;}
  },1800);
 }catch(e){}
}
function showNewBookingPopup(j){
 if(!online)return;
 hideIdleWaitingHome();
 if(!j?.id)return;
 recordLeadNotification(j);
 const overlay=document.querySelector('#homeMap .partnerMapOverlay');
 const card=document.getElementById('partnerBookingRequest');
 if(!card)return;
 // Booking request is a global partner alert: it must stay visible even when
 // the partner is on Home, Earning, Bill, or Profile. Move it outside the
 // Home map container so hidden screens cannot hide the request.
 if(card.parentElement!==document.body)document.body.appendChild(card);
 card.classList.add('globalBookingRequest');
 if(overlay)setHomeWaitingState(false);
 clearTimeout(window.dhsRequestTimer);
 clearInterval(window.dhsRequestCountdown);
 const customer=first(j,['costumername','customerName','customer'],'Customer');
 const service=first(j,['service','serviceType'],'Service');
 const distanceRaw=first(j,['distance','distanceKm','km','distanceInKm'],'');
 const eta=first(j,['distanceText','pickupDistance','eta','customerDistance'],'');
 let distance=distanceRaw ? (String(distanceRaw).toLowerCase().includes('km')?String(distanceRaw):String(distanceRaw)+' km') : '';
 if(eta) distance=String(eta);
 if(!distance) distance='Customer distance unavailable';
 notifiedJobs.add(String(j.id));
 playAlert();
 if(overlay){overlay.classList.remove('routeActive');overlay.classList.add('requestActive');}
 const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v};
 set('requestCustomerName',customer);set('requestService',service);set('requestDistance',distance+' away');
 const btn=document.getElementById('requestAcceptBtn');
 if(btn){btn.onclick=async()=>{clearTimeout(window.dhsRequestTimer);clearInterval(window.dhsRequestCountdown);overlay.classList.remove('requestActive');await jobDecision(j.id,'ACCEPTED')}}
 let left=15;set('requestTimer',left+'s');
 window.dhsRequestCountdown=setInterval(()=>{left--;set('requestTimer',Math.max(left,0)+'s');if(left<=0)clearInterval(window.dhsRequestCountdown)},1000);
 window.dhsRequestTimer=setTimeout(async()=>{
   clearInterval(window.dhsRequestCountdown);
   overlay.classList.remove('requestActive');
   card.style.display='none';card.classList.remove('globalBookingRequest');
   set('requestTimer','15s');
   await expireUnacceptedBooking(j);
 },15000);
 card.style.display='block';
}
async function expireUnacceptedBooking(j){
 try{
  if(!j?.id)return;
  // Remove it from the Partner-side queue. Keep the Admin booking record but mark this send as expired.
  await db.collection('partnerJobs').doc(String(j.id)).delete();
  try{await db.collection('bookings').doc(String(j.id)).set({partnerStatus:'EXPIRED',bookingStatus:'NEW',SentToPartner:false,sentToPartner:false,partnerExpiredAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true})}catch(e){console.warn('booking expiry sync',e)}
  jobs=jobs.filter(x=>x.id!==j.id);renderJobs();
  if(activeRouteJob?.id===j.id)activeRouteJob=null;
 }catch(e){console.warn('expire booking failed',e);jobs=jobs.filter(x=>x.id!==j?.id);renderJobs()}
}
function showAcceptedPopup(j){
 document.getElementById('acceptedPop')?.remove();
 const customer=first(j,['costumername','customerName'],'Customer'),addr=first(j,['costumerAddress','customerAddress','address'],'Address not available');
 document.body.insertAdjacentHTML('beforeend',`<div class="modalBack" id="acceptedPop"><div class="modal workGlass acceptedDhsPopup acceptedSimplePopup"><div class="acceptedDhsBrand"><span class="dhsD">D</span><span class="dhsH">H</span><span class="dhsS">S</span></div><div class="acceptedLoading"><div class="flow-spinner"></div><h3>Booking Accepted</h3></div><div class="acceptedCustomerDetails"><div><small>Customer Name</small><b>${esc(customer)}</b></div><div><small>Customer Address</small><b>${esc(addr)}</b></div></div></div></div>`);
 setTimeout(()=>{document.getElementById('acceptedPop')?.remove();startJob(j.id)},2000);
}
async function jobDecision(id,status){
 try{
  let j=jobs.find(x=>x.id===id)||{};
  if(!j.id){const snap=await db.collection('partnerJobs').doc(id).get();if(snap.exists)j={id:snap.id,...snap.data()};}
   try{const bs=await db.collection('bookings').doc(id).get();if(bs.exists)j={...bs.data(),...j,id};}catch(e){console.warn('booking phone lookup',e)}
  const patch={Stuts:status,partnerStatus:status,bookingStatus:status==='ACCEPTED'?'ACCEPTED':status==='REJECTED'?'REJECTED':'NEW',workeruid:user.uid,workeremail:user.email,partnerId:user.uid,partnerEmail:user.email,UpdatedAt:firebase.firestore.FieldValue.serverTimestamp(),updatedBy:user.uid,partnerUpdatedAt:firebase.firestore.FieldValue.serverTimestamp()};
  await db.collection('partnerJobs').doc(id).set(patch,{merge:true});
  try{await db.collection('bookings').doc(id).set({partnerStatus:status,bookingStatus:status==='ACCEPTED'?'ACCEPTED':status==='REJECTED'?'REJECTED':'NEW',workeruid:user.uid,workeremail:user.email,partnerId:user.uid,partnerEmail:user.email,UpdatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true})}catch(e){}
  try{await db.collection('notifications').add({type:'partner_booking_status',bookingId:id,partnerId:user.uid,workerid:profile?.id||user.uid,status,customerName:first(j,['costumername','customerName'],'Customer'),service:first(j,['service'],'Service'),createdAt:firebase.firestore.FieldValue.serverTimestamp()})}catch(e){}
  await syncPartnerAdmin({lastAction:status==='ACCEPTED'?'ACCEPT_BOOKING':'REJECT_BOOKING',currentBookingId:id,currentBookingStatus:status});
  if(status==='ACCEPTED'){
    hideIdleWaitingHome();document.getElementById('np')?.remove();document.getElementById('acceptedPop')?.remove();
    document.querySelector('#homeMap .partnerMapOverlay')?.classList.remove('requestActive');document.getElementById('partnerBookingRequest')?.style.setProperty('display','none');document.getElementById('partnerBookingRequest')?.classList.remove('globalBookingRequest');
    activeRouteJob=j;setMapJob(j);renderJobs();openLiveMap(j);startRouteAnimation(j);
    const sb=document.getElementById('routeCompleteBtn');if(sb){sb.classList.add('startJobBtn');sb.disabled=false;sb.innerHTML='<span class="startJobIcon">▶</span> Start Job';sb.onclick=()=>startJob(j.id)}
    toast('Booking accepted • Start Job is ready');
  }else{document.getElementById('np')?.remove();toast('Booking rejected')}
 }catch(e){toast(e.message||'Booking action failed')}
}
let activeRouteJob=null,partnerLat=null,partnerLng=null,arrivalTimer=null;const notifiedJobs=new Set();
function openLiveMap(j){
 const card=document.getElementById('mapCard');
 if(!card)return;
 card.classList.add('mapFullHost');
 document.getElementById('homeMap')?.classList.add('fullscreenMap');
 document.body.classList.add('liveMapOpen');
 setHomeWaitingState(false);
 document.querySelector('#homeMap .partnerMapOverlay')?.classList.remove('requestActive');
 setMapJob(j||activeRouteJob);
}
function closeLiveMap(){
 document.getElementById('mapCard')?.classList.remove('mapFullHost');
 document.getElementById('homeMap')?.classList.remove('fullscreenMap');
 document.body.classList.remove('liveMapOpen');
 setHomeWaitingState(true);
 setTimeout(()=>window.dhsRouteMap?.invalidateSize(),120);
 document.querySelector('#homeMap .partnerMapOverlay')?.classList.remove('routeActive','requestActive');
 clearTimeout(window.dhsRequestTimer);clearInterval(window.dhsRequestCountdown);
}
function setMapJob(j){
 if(!j)return;
 activeRouteJob=j;
 let addr=first(j,['costumerAddress','customerAddress','address'],'Customer location');
 let lat=first(j,['customerLat','costumerLat','destinationLat','customerLatitude'],'');
 let lng=first(j,['customerLng','costumerLng','destinationLng','customerLongitude'],'');
 let customer=first(j,['costumername','customerName','customer'],'Customer');
 let service=first(j,['service','serviceType'],'Service');
 let phone=getCustomerPhoneFromJob(j);
 let partnerName=first(profile,['name'],user?.displayName||'DHS Partner');
 let partnerAddr=first(profile,['address','area','location'],'Your location');
 initRouteMap();
 window.dhsDestination={lat:lat?Number(lat):null,lng:lng?Number(lng):null,address:addr};
 const set=(id,v)=>{let e=document.getElementById(id);if(e)e.textContent=v};
 set('mapCustomerName',customer);set('mapCustomerAddress',addr);set('mapPartnerName',partnerName);set('mapPartnerAddress',partnerAddr);set('mapService',service);set('mapCustomerLabel',customer+' 😄');
 let cb=document.getElementById('mapCallBtn');if(cb)cb.dataset.phone=phone;let rb=document.getElementById('routeCallBtn');if(rb){const np=normalizeCustomerPhone(getCustomerPhoneFromJob(j));rb.dataset.phone=np;rb.href=np?'tel:'+np:'tel:';rb.onclick=()=>{if(np){callCustomerNumber(np);return false;}toast('Customer phone number not available');return false;};}
 let note=document.getElementById('mapNote');if(note)note.textContent='📍 '+addr;
 let pin=document.getElementById('jobPin');if(pin)pin.style.display='block';
 updateMapDistance(j);
}
function updateMapDistance(j){
 let d=first(j,['distance','distanceKm','km','distanceInKm'],'');
 let el=document.getElementById('mapDistance');
 if(el)el.textContent=d?(String(d).toLowerCase().includes('km')?d:String(d)+' km'):'—';
}
function getActiveCustomerJob(){return activeRouteJob||jobs.find(x=>['ACCEPTED','ON_THE_WAY','ARRIVED','WORKING'].includes(jobState(x)))||null}
function customerPhone(j){return getCustomerPhoneFromJob(j)}
function customerDestination(j){
 let geo=first(j||{},['customerLocation','costumerLocation','location','geopoint'],null);
 let lat=first(j||{},['customerLat','costumerLat','destinationLat','customerLatitude'],'');
 let lng=first(j||{},['customerLng','costumerLng','destinationLng','customerLongitude'],'');
 if(geo&&typeof geo==='object'){lat=lat||geo.latitude;lng=lng||geo.longitude;}
 const raw=String(first(j||{},['mapsUrl','mapUrl','googleMapsUrl','customerMapsUrl'],'')||'');
 if((!lat||!lng)&&raw){
   const m=raw.match(/[?&](?:q|query|destination|ll|center)=(-?\d+(?:\.\d+)?)[, ]+(-?\d+(?:\.\d+)?)/i)
     ||raw.match(/@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/)
     ||raw.match(/(-?\d{1,2}\.\d+)\s*[, ]\s*(-?\d{2,3}\.\d+)/);
   if(m){lat=m[1];lng=m[2];}
 }
 return {lat,lng,address:first(j||{},['costumerAddress','customerAddress','address'],'Delhi, India')};
}
function openSlideAction(kind){
 const j=getActiveCustomerJob();
 if(!j){toast('No active customer job');return;}
 const isCall=kind==='call';
 const title=isCall?'Call Customer':'Navigate to Customer';
 const sub=isCall?'Slide fully to call the customer.':'Slide fully to open Google Maps with the customer destination.';
 showModal(`<div class="modalHead"><h3>${isCall?'📞':'➤'} ${title}</h3><button class="close" onclick="closeModal()">✕</button></div><p class="muted">${sub}</p><div class="slideCallWrap"><div class="slideTrack ${isCall?'dhs':'nav'}"><div class="slideThumb" id="jobSlideThumb">➜</div><span id="jobSlideText">Slide to ${isCall?'call':'navigate'}</span><input class="slideRange" id="jobSlideRange" type="range" min="0" max="100" value="0" oninput="slideJobAction(this,'${kind}')"></div></div>`);
}

function slideJobAction(input,kind){
 const pct=Number(input.value||0),track=input.parentElement,thumb=track.querySelector('#jobSlideThumb'),text=track.querySelector('#jobSlideText');
 const max=Math.max(0,track.clientWidth-thumb.offsetWidth-10);
 thumb.style.left=(5+max*(pct/100))+'px';
 if(text)text.textContent=pct>=100?(kind==='call'?'Calling…':'Opening Google Maps…'):`Slide to ${kind==='call'?'call':'navigate'}`;
 if(pct>=100&&!window._jobSlideBusy){
  window._jobSlideBusy=true;
  const j=getActiveCustomerJob();
  setTimeout(()=>{
   closeModal();window._jobSlideBusy=false;if(!j)return;
   if(kind==='call'){
    const phone=getCustomerPhoneFromJob(j);
    if(!phone){toast('Customer phone number not available');return;}
    callCustomerNumber(phone);
   }else{
    const d=customerDestination(j);
    openMapsNavigation(d, j);
   }
  },260);
 }
}

function normalizeCustomerPhone(v){let d=String(v??'').replace(/\D/g,'');if(d.length===11&&d[0]==='0')d=d.slice(1);if(d.length===10)d='91'+d;return d.length>=10&&d.length<=15?'+'+d:'';}
function getCustomerPhoneFromJob(j){if(!j)return '';for(const k of ['costumerphone','costumerPhone','customerPhone','customerphone','customerMobile','customerMobileNumber','customer_number','customerPhoneNumber','phone','mobile','mobileNumber','contactNumber','contact','phoneNumber','phoneNo','mobileNo'])if(j[k]!=null&&String(j[k]).trim())return String(j[k]).trim();for(const c of [j.customer,j.costumer,j.customerDetails,j.customerData,j.customerInfo])if(c&&typeof c==='object')for(const k of ['phone','mobile','mobileNumber','phoneNumber','contactNumber','phoneNo','mobileNo'])if(c[k]!=null&&String(c[k]).trim())return String(c[k]).trim();return '';}
function callCustomerNumber(v){const p=normalizeCustomerPhone(v);if(!p){toast('Customer phone number not available');return false;}const a=document.getElementById('routeCallBtn');if(a)a.href='tel:'+p;const m=document.getElementById('mapCallBtn');if(m)m.dataset.phone=p;try{window.location.href='tel:'+p;return true}catch(e){try{window.open('tel:'+p,'_self');return true}catch(x){toast('Unable to open phone dialer');return false}}}
function callCustomerByJob(id){const j=jobs.find(x=>String(x.id)===String(id));if(!j){toast('Customer booking not found');return false}return callCustomerNumber(getCustomerPhoneFromJob(j));}
function callActiveCustomer(){const j=(activeRouteJob&&['ACCEPTED','ON_THE_WAY','ARRIVED','WORKING'].includes(jobState(activeRouteJob)))?activeRouteJob:jobs.find(x=>['ACCEPTED','ON_THE_WAY','ARRIVED','WORKING'].includes(jobState(x)));if(!j){toast('No accepted customer booking');return false;}return callCustomerNumber(getCustomerPhoneFromJob(j));}
function openMapsNavigation(d,j){
 try{
  d=d||customerDestination(j);
  const raw=String(first(j||{},['mapsUrl','mapUrl','googleMapsUrl','customerMapsUrl','costumerLocation','customerLocation'],'')||'').trim();
  const destination=(d.lat&&d.lng)?String(d.lat)+','+String(d.lng):(raw||d.address||'Delhi, India');
  // Native Android bridge opens the Google Maps application, not a WebView page.
  // Always send a clean Google Maps Directions URL to the native bridge.
  // Include the partner's current GPS position when available so Google Maps
  // can calculate a real driving route and show its route/Start UI.
  const origin=(partnerLat!=null&&partnerLng!=null)?String(partnerLat)+','+String(partnerLng):'';
  const mapsDirections='https://www.google.com/maps/dir/?api=1'+(origin?'&origin='+encodeURIComponent(origin):'')+'&destination='+encodeURIComponent(destination)+'&travelmode=driving&dir_action=preview';
  if(window.Android&&typeof window.Android.openGoogleMaps==='function'){
    window.Android.openGoogleMaps(mapsDirections);
    return;
  }
  // If this is running outside Android WebView, use a proper Directions URL.
  // Keep the customer's original Maps URL only when it is already a clean Maps URL.
  if(raw && /^(https?:\/\/)?(www\.)?(google\.com\/maps|maps\.google\.com|maps\.app\.goo\.gl|goo\.gl\/maps)/i.test(raw)){window.open(raw,'_blank');return;}
  window.open(mapsDirections,'_blank');
 }catch(e){toast('Unable to open Google Maps');}
}
function navigateToCustomer(){
 let j=activeRouteJob||jobs.find(x=>['ACCEPTED','ON_THE_WAY','ARRIVED','WORKING'].includes(jobState(x)));
 if(!j){toast('No active customer job');return}
 openMapsNavigation(customerDestination(j),j);
}

function centerPartnerMap(){
 try{navigator.geolocation?.getCurrentPosition(pos=>{partnerLat=pos.coords.latitude;partnerLng=pos.coords.longitude;initRouteMap();window.dhsRouteMap?.setView([partnerLat,partnerLng],16,{animate:true});if(activeRouteJob)buildRoadRoute(activeRouteJob);toast('My location updated')},()=>toast('Location permission required'),{enableHighAccuracy:true,timeout:8000})}catch(e){}
}
function toggleMapMode(){
 const b=document.getElementById('mapModeBtn');
 if(b){const isSat=b.dataset.sat==='1';b.dataset.sat=isSat?'0':'1';b.textContent=isSat?'2D':'SAT';}
 const map=window.dhsRouteMap;if(map){const street=window.dhsStreetLayer,sat=window.dhsSatLayer;if(b?.dataset.sat==='1'){if(street&&map.hasLayer(street))map.removeLayer(street);if(sat&&!map.hasLayer(sat))sat.addTo(map)}else{if(sat&&map.hasLayer(sat))map.removeLayer(sat);if(street&&!map.hasLayer(street))street.addTo(map)}}
}
function makeRouteIcon(kind){return L.divIcon({className:'',html:`<div class="routeMarker ${kind}">${kind==='me'?'➤':'📍'}</div>`,iconSize:[40,40],iconAnchor:[20,20]})}
function initRouteMap(){
 if(!window.L)return;
 const el=document.getElementById('routeLeafletMap');if(!el)return;
 if(!window.dhsRouteMap){
  window.dhsRouteMap=L.map(el,{zoomControl:true,attributionControl:true,zoomSnap:.25,zoomDelta:.5}).setView([28.6139,77.2090],12);
  window.dhsStreetLayer=L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:20,attribution:'© OpenStreetMap contributors'}).addTo(window.dhsRouteMap);
  window.dhsSatLayer=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',{maxZoom:19,attribution:'Tiles © Esri'});
  window.dhsRouteLayer=L.layerGroup().addTo(window.dhsRouteMap);
  setTimeout(()=>window.dhsRouteMap.invalidateSize(),150);
 }else setTimeout(()=>window.dhsRouteMap.invalidateSize(),80);
}
function routePoint(v){return v!==''&&v!=null&&isFinite(Number(v))?Number(v):null}
async function geocodeAddress(addr){
 try{const r=await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=in&q='+encodeURIComponent(addr));const a=await r.json();if(a?.[0])return[Number(a[0].lat),Number(a[0].lon)];}catch(e){} return null;
}
function makeBikeIcon(angle=0){
 const a=Number.isFinite(angle)?angle:0;
 return L.divIcon({className:'routeBikeIcon',html:`<div class="bike" style="transform:rotate(${a}deg)">🏍️</div>`,iconSize:[42,42],iconAnchor:[21,21]});
}
function routeBearing(a,b){
 const lat1=a[0]*Math.PI/180,lat2=b[0]*Math.PI/180,dlon=(b[1]-a[1])*Math.PI/180;
 const y=Math.sin(dlon)*Math.cos(lat2),x=Math.cos(lat1)*Math.sin(lat2)-Math.sin(lat1)*Math.cos(lat2)*Math.cos(dlon);
 return Math.atan2(y,x)*180/Math.PI;
}
function stopRouteBike(){
 if(window.dhsBikeAnimation){cancelAnimationFrame(window.dhsBikeAnimation);window.dhsBikeAnimation=null;}
 if(window.dhsBikeMarker&&window.dhsRouteLayer){try{window.dhsRouteLayer.removeLayer(window.dhsBikeMarker)}catch(e){}}
 window.dhsBikeMarker=null;
}
function animateBikeAlongRoute(latlngs,durationMs=18000){
 stopRouteBike();
 if(!latlngs||latlngs.length<2)return;
 const map=window.dhsRouteMap,layer=window.dhsRouteLayer;if(!map||!layer)return;
 const marker=L.marker(latlngs[0],{icon:makeBikeIcon(routeBearing(latlngs[0],latlngs[1])),zIndexOffset:2000,interactive:false}).addTo(layer);
 window.dhsBikeMarker=marker;
 const started=performance.now();
 const step=now=>{
   const t=Math.min(1,(now-started)/durationMs);
   const idx=t*(latlngs.length-1),i=Math.min(latlngs.length-2,Math.floor(idx)),f=idx-i;
   const a=latlngs[i],b=latlngs[i+1];
   const pos=[a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f];
   marker.setLatLng(pos).setIcon(makeBikeIcon(routeBearing(a,b)));
   if(t<1)window.dhsBikeAnimation=requestAnimationFrame(step);else window.dhsBikeAnimation=null;
 };
 window.dhsBikeAnimation=requestAnimationFrame(step);
}
function setMap3D(on=true){
 const el=document.getElementById('routeLeafletMap');
 if(el)el.classList.toggle('map3d',!!on);
 const b=document.getElementById('mapModeBtn');if(b){b.dataset.sat=on?'0':(b.dataset.sat||'0');b.textContent=on?'3D':'2D';}
}
function toggleMapMode(){
 const b=document.getElementById('mapModeBtn'),map=window.dhsRouteMap;
 if(!map)return;
 const street=window.dhsStreetLayer,sat=window.dhsSatLayer;
 const satOn=b?.dataset.sat==='1';
 if(satOn){
   if(sat&&map.hasLayer(sat))map.removeLayer(sat);if(street&&!map.hasLayer(street))street.addTo(map);
   if(b){b.dataset.sat='0';b.textContent='3D';} setMap3D(true);
 }else{
   if(street&&map.hasLayer(street))map.removeLayer(street);if(sat&&!map.hasLayer(sat))sat.addTo(map);
   if(b){b.dataset.sat='1';b.textContent='2D';} setMap3D(false);
 }
 setTimeout(()=>map.invalidateSize(),120);
}
function makeRouteIcon(kind){return L.divIcon({className:'',html:`<div class="routeMarker ${kind}">${kind==='me'?'➤':'📍'}</div>`,iconSize:[40,40],iconAnchor:[20,20]})}
function initRouteMap(){
 if(!window.L)return;
 const el=document.getElementById('routeLeafletMap');if(!el)return;
 if(!window.dhsRouteMap){
  window.dhsRouteMap=L.map(el,{zoomControl:true,attributionControl:true,zoomSnap:.25,zoomDelta:.5}).setView([28.6139,77.2090],12);
  window.dhsStreetLayer=L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:20,attribution:'© OpenStreetMap contributors'}).addTo(window.dhsRouteMap);
  window.dhsSatLayer=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',{maxZoom:19,attribution:'Tiles © Esri'});
  window.dhsRouteLayer=L.layerGroup().addTo(window.dhsRouteMap);
  setMap3D(true);
  setTimeout(()=>window.dhsRouteMap.invalidateSize(),150);
 }else setTimeout(()=>window.dhsRouteMap.invalidateSize(),80);
}
function routePoint(v){return v!==''&&v!=null&&isFinite(Number(v))?Number(v):null}
async function geocodeAddress(addr){
 try{const r=await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=in&q='+encodeURIComponent(addr));const a=await r.json();if(a?.[0])return[Number(a[0].lat),Number(a[0].lon)];}catch(e){} return null;
}
async function buildRoadRoute(j){
 initRouteMap();const map=window.dhsRouteMap,layer=window.dhsRouteLayer;if(!map||!layer)return null;
 stopRouteBike();layer.clearLayers();
 const locationText=first(j,['location','Location','customerLocation','costumerLocation','mapsUrl','mapUrl','googleMapsUrl','customerMapsUrl','costumerAddress','customerAddress','address'],'');
 let dLat=routePoint(first(j,['customerLat','costumerLat','destinationLat','customerLatitude','lat','latitude'],''));
 let dLng=routePoint(first(j,['customerLng','costumerLng','destinationLng','customerLongitude','lng','longitude'],''));
 // DHS bookings sometimes store only a Google Maps URL such as ?q=28.5889514,77.2556474.
 if(dLat===null||dLng===null){
   const m=String(locationText||'').match(/[?&]q=(-?\d+(?:\.\d+)?)[, ]+(-?\d+(?:\.\d+)?)/i)||String(locationText||'').match(/(-?\d{1,2}\.\d+)\s*[, ]\s*(-?\d{2,3}\.\d+)/);
   if(m){dLat=Number(m[1]);dLng=Number(m[2]);}
 }
 if(dLat===null||dLng===null){const g=await geocodeAddress(locationText||'Delhi, India');if(g){dLat=g[0];dLng=g[1];}}
 if(dLat===null||dLng===null){toast('Customer location coordinates unavailable');return null;}
 let origin=null;
 try{await new Promise(resolve=>navigator.geolocation.getCurrentPosition(p=>{origin=[p.coords.latitude,p.coords.longitude];partnerLat=p.coords.latitude;partnerLng=p.coords.longitude;resolve()},()=>resolve(),{enableHighAccuracy:true,timeout:9000,maximumAge:10000}))}catch(e){}
 if(!origin){origin=[28.6139,77.2090];}
 const me=L.marker(origin,{icon:makeRouteIcon('me'),zIndexOffset:1000}).addTo(layer).bindTooltip('You (Partner)',{direction:'top'});
 const customer=L.marker([dLat,dLng],{icon:makeRouteIcon('customer'),zIndexOffset:900}).addTo(layer).bindTooltip(first(j,['costumername','customerName','customer'],'Customer'),{direction:'top'});
 const routeUrl=`https://router.project-osrm.org/route/v1/driving/${origin[1]},${origin[0]};${dLng},${dLat}?overview=full&geometries=geojson&steps=true`;
 try{
  const r=await fetch(routeUrl);const data=await r.json();const rt=data?.routes?.[0];if(!rt)throw new Error('route unavailable');
  const latlngs=rt.geometry.coordinates.map(c=>[c[1],c[0]]);
  L.polyline(latlngs,{color:'#ffffff',weight:13,opacity:.55,lineCap:'round',lineJoin:'round',className:'routeGlowLine'}).addTo(layer);
  L.polyline(latlngs,{color:'#ff8a24',weight:7,opacity:.96,lineCap:'round',lineJoin:'round'}).addTo(layer);
  const bounds=L.latLngBounds(latlngs);map.fitBounds(bounds,{paddingTopLeft:[18,145],paddingBottomRight:[18,185]});
  setMap3D(true);
  const km=(rt.distance/1000).toFixed(1),mins=Math.max(1,Math.round(rt.duration/60));
  const rs=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v};
  rs('mapDistance',km+' km');rs('routeNavDistance',km+' km');rs('routeTripMain',mins+' min · '+km+' km');
  const steps=rt.legs?.[0]?.steps||[];
  let street=first(j,['customerStreet','street','road'],'');
  if(!street){const step=steps.find(x=>x?.name);if(step?.name)street=step.name;}
  rs('routeNavStreet',street||'Follow road route');
  // Put named roads/areas directly on the route so the partner can see which roads/areas are coming next.
  const names=[...new Set(steps.map(x=>String(x?.name||'').trim()).filter(n=>n&&n!=='-'))].slice(0,8);
  const areaText=String(first(j,['area','customerArea','costumerArea','locality','customerLocality'],'')||'').trim();
  const labels=[...new Set([areaText,...names].filter(Boolean))].slice(0,9);
  const labelLayer=L.layerGroup().addTo(layer);
  if(labels.length&&latlngs.length>2){
    labels.forEach((name,idx)=>{
      const point=latlngs[Math.min(latlngs.length-1,Math.max(0,Math.round((idx+1)*latlngs.length/(labels.length+1))))];
      L.marker(point,{icon:L.divIcon({className:'routeRoadLabel',html:'<span>'+esc(name)+'</span>',iconSize:null,iconAnchor:[0,18]}),interactive:false,zIndexOffset:300}).addTo(labelLayer);
    });
  }
  const routeRoads=document.getElementById('routeRoadNames');
  if(routeRoads)routeRoads.innerHTML=labels.map(n=>'<span>'+esc(n)+'</span>').join('');
  window.dhsRouteData={origin,destination:[dLat,dLng],distanceKm:Number(km),durationMin:mins,route:rt,latlngs,roadNames:labels};
  animateBikeAlongRoute(latlngs,Math.max(12000,Math.min(30000,mins*2200)));
  return window.dhsRouteData;
 }catch(e){
  const fallback=[origin,[dLat,dLng]];
  L.polyline(fallback,{color:'#ffffff',weight:12,opacity:.45,lineCap:'round'}).addTo(layer);
  L.polyline(fallback,{color:'#ff8a24',weight:7,opacity:.95,dashArray:'10 8',lineCap:'round'}).addTo(layer);
  map.fitBounds(L.latLngBounds(fallback),{padding:[80,60]});setMap3D(true);toast('Road route unavailable; showing fallback route');return null;
 }
}
let workTimer=null,workStartedAtMs=0,workElapsedSeconds=0;
function formatWorkDuration(sec){sec=Math.max(0,Math.floor(Number(sec)||0));const h=String(Math.floor(sec/3600)).padStart(2,'0'),m=String(Math.floor((sec%3600)/60)).padStart(2,'0'),ss=String(sec%60).padStart(2,'0');return `${h}:${m}:${ss}`}
function updateWorkTimer(){workElapsedSeconds=Math.max(0,Math.floor((Date.now()-workStartedAtMs)/1000));const el=document.getElementById('jobTimerValue');if(el)el.textContent=formatWorkDuration(workElapsedSeconds)}
function showJobTimerPopup(j){
 try{window.DHSBridge?.setJobTimerBackLocked(true)}catch(e){}
 clearInterval(workTimer);workStartedAtMs=Number(j?.workStartedAtMs)||Date.now();workElapsedSeconds=Math.max(0,Math.floor((Date.now()-workStartedAtMs)/1000));document.getElementById('jobTimerPopup')?.remove();
 const customer=first(j,['costumername','customerName','customer'],'Customer'),service=first(j,['service','serviceType'],'Service');
 document.body.insertAdjacentHTML('beforeend',`<div class="jobTimerOverlay" id="jobTimerPopup"><div class="jobTimerPopup">
 <div class="jobTimerTitle"><span class="timerClockIcon"><svg viewBox="0 0 24 24"><circle cx="12" cy="13" r="8"/><path d="M12 9v5l3 2"/><path d="M9 2h6"/><path d="M12 2v3"/></svg></span> JOB TIMER</div>
 <div class="jobTimerPanel"><div class="jobTimerValue" id="jobTimerValue">${formatWorkDuration(workElapsedSeconds)}</div><div class="jobTimerLabels"><span>Hours</span><span>Minutes</span><span>Seconds</span></div></div>
 <div class="jobTimerWorkerWrap"><div class="orbitSpin"><img src="images/dhs-tools-orbit.png" alt="DHS tools"/></div><img class="jobTimerWorker" src="images/worker.png" alt="DHS Partner worker"/></div>
 <div class="jobTimerCustomer"><b>${esc(customer)}</b><span>${esc(service)}</span></div>
 <button class="jobTimerComplete" onclick="completeTimedJob('${esc(j.id)}')"><span>✓</span> COMPLETE JOB</button>
 </div></div>`);updateWorkTimer();workTimer=setInterval(updateWorkTimer,500);
}
function closeJobTimerPopup(){clearInterval(workTimer);workTimer=null;document.getElementById('jobTimerPopup')?.remove();try{window.DHSBridge?.setJobTimerBackLocked(false)}catch(e){}}
async function startJob(id){
 try{
  let j=jobs.find(x=>x.id===id);if(!j){const snap=await db.collection('partnerJobs').doc(id).get();if(!snap.exists){toast('Booking not found');return}j={id:snap.id,...snap.data()};}
  if(!['ACCEPTED','ON_THE_WAY','WORKING','ARRIVED'].includes(jobState(j))){toast('Please accept this booking first');return}
  activeRouteJob=j;workStartedAtMs=Date.now();workElapsedSeconds=0;clearInterval(workTimer);
  const now=firebase.firestore.FieldValue.serverTimestamp(),startMs=workStartedAtMs;
  const patch={Stuts:'WORKING',partnerStatus:'WORKING',bookingStatus:'WORKING',workeruid:user.uid,workeremail:user.email,partnerId:user.uid,partnerEmail:user.email,startedAt:now,workStartedAt:now,workStartedAtMs:startMs,UpdatedAt:now,updatedBy:user.uid,currentActivity:'WORKING - JOB TIMER'};
  await db.collection('partnerJobs').doc(id).set(patch,{merge:true});
  try{await db.collection('bookings').doc(id).set({partnerStatus:'WORKING',bookingStatus:'WORKING',workeruid:user.uid,workeremail:user.email,partnerId:user.uid,partnerEmail:user.email,startedAt:now,workStartedAt:now,workStartedAtMs:startMs,UpdatedAt:now},{merge:true})}catch(e){console.warn('booking start sync',e)}
  try{await db.collection('notifications').add({type:'partner_start_job',bookingId:id,partnerId:user.uid,workerid:profile?.id||user.uid,customerName:first(j,['costumername','customerName','customer'],'Customer'),service:first(j,['service','serviceType'],'Service'),status:'WORKING',createdAt:firebase.firestore.FieldValue.serverTimestamp()})}catch(e){}
  await syncPartnerAdmin({lastAction:'START_JOB',currentBookingId:id,currentBookingStatus:'WORKING'});
  Object.assign(j,patch);const idx=jobs.findIndex(x=>x.id===id);if(idx>=0)jobs[idx]=j;
  setMapJob(j);openLiveMap(j);document.querySelector('#homeMap .partnerMapOverlay')?.classList.add('routeActive');
  const st=document.getElementById('mapStatus');if(st)st.textContent='WORKING';const live=document.getElementById('mapLiveStatus');if(live)live.textContent='WORKING';
  showJobTimerPopup(j);
 }catch(e){toast(e.message||'Start Job failed')}
}
async function completeTimedJob(id){
 const j=jobs.find(x=>String(x.id)===String(id))||activeRouteJob;
 if(!j?.id){toast('Active customer job not found');return}
 if(window.dhsCompletingJob)return;
 window.dhsCompletingJob=true;
 clearInterval(workTimer);workTimer=null;
 const duration=Math.max(0,Math.floor((Date.now()-(Number(j.workStartedAtMs)||workStartedAtMs||Date.now()))/1000));
 const completedMs=Date.now();
 try{
  const now=firebase.firestore.FieldValue.serverTimestamp();
  const patch={Stuts:'COMPLETED',partnerStatus:'COMPLETED',bookingStatus:'COMPLETED',completedAt:now,completedAtMs:completedMs,workCompletedAt:now,workCompletedAtMs:completedMs,workDurationSeconds:duration,completedBy:user.uid,UpdatedAt:now,updatedBy:user.uid,currentActivity:'JOB COMPLETED'};

  // Save completion to the partner job first. The success screen must not be blocked by
  // optional admin/notification sync calls (an old sync error was preventing the popup).
  await db.collection('partnerJobs').doc(j.id).set(patch,{merge:true});
  Object.assign(j,patch,{completedAtMs:completedMs,workDurationSeconds:duration});
  const idx=jobs.findIndex(x=>x.id===j.id);if(idx>=0)jobs[idx]=j;

  // Secondary syncs are best-effort and must never stop the completion flow.
  Promise.resolve().then(async()=>{
    try{await db.collection('bookings').doc(j.id).set(patch,{merge:true})}catch(e){console.warn('complete booking sync',e)}
    try{await syncPartnerAdmin({lastAction:'COMPLETE_JOB',currentBookingId:j.id,currentBookingStatus:'COMPLETED',workDurationSeconds:duration})}catch(e){console.warn('admin completion sync',e)}
  });

  // IMPORTANT: do not call an undefined sound function here. It previously threw a
  // ReferenceError before the success popup could be displayed.
  try{if(typeof playCompletionSound==='function')playCompletionSound()}catch(e){}
  document.getElementById('jobTimerPopup')?.remove();
  try{window.DHSBridge?.setJobTimerBackLocked(false)}catch(e){}
  document.getElementById('jobCompleteSuccess')?.remove();
  document.body.insertAdjacentHTML('beforeend',`<div class="phoneSuccessOverlay" id="jobCompleteSuccess"><div class="phoneSuccessBox"><div class="phoneSuccessIcon">✓</div><div class="phoneSuccessTitle">Job Completed Successfully</div><div class="phoneSuccessSub">DHS Partner • ${esc(first(j,['costumername','customerName'],'Customer'))}<br>${esc(first(j,['service','serviceType'],'Service'))} • ${esc(first(j,['costumerAddress','customerAddress','address'],'Customer Address'))}<br>Job Time • ${formatWorkDuration(duration)}</div><div class="phoneSuccessRing"></div></div></div>`);
  setTimeout(()=>{
    document.getElementById('jobCompleteSuccess')?.remove();
    closeLiveMap();
    try{stopRouteBike?.()}catch(e){}
    document.querySelectorAll('.modalBack,.notificationPop').forEach(el=>el.remove());
    activeRouteJob=null;
    currentPage='home';
    document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));
    document.getElementById('home')?.classList.add('active');
    document.querySelectorAll('.bottom button').forEach(x=>x.classList.remove('active'));
    document.querySelector('[data-page="home"]')?.classList.add('active');
    renderJobs();renderEarnings();
    requestAnimationFrame(()=>{document.documentElement.scrollTop=0;document.body.scrollTop=0;window.scrollTo(0,0)});
  },3000);
 }catch(e){toast('Job complete failed: '+(e.message||e))}
 finally{window.dhsCompletingJob=false}
}
async function completeRouteJob(){return completeTimedJob(activeRouteJob?.id)}
async function startRouteAnimation(j){
 openLiveMap(j);
 document.querySelector('#homeMap .partnerMapOverlay')?.classList.remove('requestActive');document.querySelector('#homeMap .partnerMapOverlay')?.classList.add('routeActive');document.getElementById('partnerBookingRequest')?.style.setProperty('display','none');document.getElementById('partnerBookingRequest')?.classList.remove('globalBookingRequest');
 const distRaw=first(j,['distance','distanceKm','km','distanceInKm'],'—');let dist=String(distRaw);if(dist!=='—'&&!dist.toLowerCase().includes('km'))dist+=' km';
 const street=first(j,['customerStreet','street','road','costumerAddress','customerAddress','address'],'Customer Route');const eta=first(j,['eta','duration','travelTime','pickupEta'],'');
 const rs=(id,v)=>{let e=document.getElementById(id);if(e)e.textContent=v};rs('routeNavDistance',dist);rs('routeNavStreet',street);rs('routeTripMain',(eta?eta+' · ':'')+dist);rs('routeTripSub','Going to '+first(j,['costumername','customerName','customer'],'customer'));
 document.getElementById('mapStatus').textContent='ON THE WAY';document.getElementById('mapLiveStatus').textContent='ON THE WAY';clearTimeout(arrivalTimer);
 let note=document.getElementById('mapNote');if(note)note.innerHTML='🧭 <b>On the way to customer</b>';
 await buildRoadRoute(j);
 const sb=document.getElementById('routeCompleteBtn');if(sb){sb.classList.add('startJobBtn');sb.disabled=false;sb.innerHTML='<span class="startJobIcon">▶</span> Start Job';sb.onclick=()=>startJob(j.id);}
}
async function markArrived(id){
 let j=jobs.find(x=>x.id===id);if(!j)return;
 stopRouteBike();setMap3D(true);
 document.getElementById('mapStatus').textContent='ARRIVED';document.getElementById('mapLiveStatus').textContent='ARRIVED';
 let note=document.getElementById('mapNote');if(note)note.innerHTML='📍 <b>Customer location reached</b>';
 try{await db.collection('partnerJobs').doc(id).set({Stuts:'ARRIVED',partnerStatus:'ARRIVED',bookingStatus:'ARRIVED',arrivedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true})}catch(e){}
}
function startWorkFromMap(){let j=activeRouteJob||jobs.find(x=>jobState(x)==='ARRIVED');if(!j)return;showWorkPopup(j)}
let workCapturePhoto=null,workCaptureVideo=null,cameraStream=null,cameraRecorder=null,cameraChunks=[],cameraMode='photo';
function completeJob(id){let j=jobs.find(x=>x.id===id);if(j)showWorkPopup(j)}
function showWorkPopup(j){showJobTimerPopup(j)}
function openWorkProof(id){clearInterval(workTimer);let j=jobs.find(x=>x.id===id);if(!j)return;workCapturePhoto=null;workCaptureVideo=null;showModal(`<div class="modalHead"><h3>Work Proof</h3><button class="close" onclick="closeModal()">✕</button></div><p class="muted">Maximum 10 photos and 2 videos. One or more proof files required.</p><div class="proofGrid"><div class="proofCard"><div class="proofTitle">Photos <span id="photoCount">0/10</span></div><button class="proofBtn" onclick="openDhsCamera('photo')">📷<span>Camera</span></button><span id="photoStatus" class="proofStatus">No photos yet</span><div id="photoThumbs"></div></div><div class="proofCard"><div class="proofTitle">Videos <span id="videoCount">0/2</span></div><button class="proofBtn" onclick="openDhsCamera('video')">🎥<span>Video Camera</span></button><span id="videoStatus" class="proofStatus">No videos yet</span><div id="videoThumbs"></div></div></div><button id="uploadCompleteBtn" class="btn orange full mt8" onclick="saveWorkProof('${esc(id)}')">Complete Work</button>`);workPhotoFiles=[];workVideoFiles=[]}
let workPhotoFiles=[],workVideoFiles=[];
async function openDhsCamera(mode){cameraMode=mode;cameraChunks=[];if(!navigator.mediaDevices?.getUserMedia){toast('Camera ke liye HTTPS/app permission required hai.');return}document.getElementById('dhsCamera')?.remove();let count=mode==='photo'?workPhotoFiles.length:workVideoFiles.length;if((mode==='photo'&&count>=10)||(mode==='video'&&count>=2)){toast(mode==='photo'?'Photo limit 10 reached':'Video limit 2 reached');return}let label=mode==='photo'?'Take Work Photo':'Record Work Video';document.body.insertAdjacentHTML('beforeend',`<div class="camera-modal" id="dhsCamera"><div class="camera-top"><h3>📷 ${label}</h3><button class="camera-close" onclick="closeDhsCamera()">✕</button></div><div class="camera-stage"><video id="cameraLive" autoplay playsinline muted></video><div class="camera-hint">DHS Partner in-app camera</div></div><div class="camera-controls"><button class="camera-secondary" onclick="switchCameraFacing()">↻ Flip</button><button id="cameraAction" class="camera-action ${mode==='video'?'record':''}" onclick="captureDhsCamera()">${mode==='video'?'●':'◉'}</button></div></div>`);try{cameraStream=await navigator.mediaDevices.getUserMedia(mode==='video'?{video:{facingMode:{ideal:'environment'}},audio:true}:{video:{facingMode:{ideal:'environment'}},audio:false});let v=document.getElementById('cameraLive');v.srcObject=cameraStream;await v.play()}catch(e){closeDhsCamera();toast('Camera permission/error: '+(e.message||'Camera open nahi hui'))}}
async function switchCameraFacing(){
 if(!cameraStream)return;const tracks=cameraStream.getVideoTracks();const current=tracks[0]?.getSettings()?.facingMode||'environment';tracks.forEach(t=>t.stop());
 try{cameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:current==='environment'?'user':'environment'}},audio:cameraMode==='video'});document.getElementById('cameraLive').srcObject=cameraStream;}catch(e){toast('Camera flip failed')}
}
function captureDhsCamera(){let v=document.getElementById('cameraLive');if(!v||!cameraStream)return;if(cameraMode==='photo'){if(workPhotoFiles.length>=10){toast('Photo limit 10 reached');return}let c=document.createElement('canvas');c.width=v.videoWidth||1080;c.height=v.videoHeight||1920;c.getContext('2d').drawImage(v,0,0,c.width,c.height);c.toBlob(blob=>{if(!blob)return;workPhotoFiles.push(new File([blob],`DHS-Work-Photo-${Date.now()}.jpg`,{type:'image/jpeg'}));closeDhsCamera();updateProofCounts()},'image/jpeg',.92);return}let btn=document.getElementById('cameraAction');if(!cameraRecorder||cameraRecorder.state==='inactive'){if(workVideoFiles.length>=2){toast('Video limit 2 reached');return}cameraChunks=[];let opts={};if(MediaRecorder.isTypeSupported('video/webm;codecs=vp9'))opts.mimeType='video/webm;codecs=vp9';else if(MediaRecorder.isTypeSupported('video/webm'))opts.mimeType='video/webm';try{cameraRecorder=new MediaRecorder(cameraStream,opts)}catch(e){toast('Video recording supported nahi hai');return}cameraRecorder.ondataavailable=e=>{if(e.data?.size)cameraChunks.push(e.data)};cameraRecorder.onstop=()=>{let type=cameraRecorder.mimeType||'video/webm';workVideoFiles.push(new File([new Blob(cameraChunks,{type})],`DHS-Work-Video-${Date.now()}.webm`,{type}));closeDhsCamera();updateProofCounts()};cameraRecorder.start(250);btn.textContent='■';btn.classList.add('record');toast('Recording started')}else{cameraRecorder.stop();btn.textContent='Saving…';btn.disabled=true}}
function updateProofCounts(){let p=document.getElementById('photoCount'),v=document.getElementById('videoCount'),ps=document.getElementById('photoStatus'),vs=document.getElementById('videoStatus');if(p)p.textContent=workPhotoFiles.length+'/10';if(v)v.textContent=workVideoFiles.length+'/2';if(ps)ps.textContent=workPhotoFiles.length?workPhotoFiles.length+' photo captured':'No photos yet';if(vs)vs.textContent=workVideoFiles.length?workVideoFiles.length+' video captured':'No videos yet'}
function closeDhsCamera(){if(cameraRecorder&&cameraRecorder.state!=='inactive'){try{cameraRecorder.stop()}catch(e){}}cameraRecorder=null;cameraStream?.getTracks().forEach(t=>t.stop());cameraStream=null;document.getElementById('dhsCamera')?.remove()}
function showProofPreview(type){
 const file=type==='photo'?workCapturePhoto:workCaptureVideo;if(!file)return;const status=document.getElementById(type==='photo'?'photoStatus':'videoStatus');const preview=document.getElementById(type==='photo'?'photoPreview':'videoPreview');if(status)status.textContent='Ready: '+file.name;if(preview){if(preview.dataset.objectUrl)URL.revokeObjectURL(preview.dataset.objectUrl);const url=URL.createObjectURL(file);preview.dataset.objectUrl=url;preview.src=url;preview.classList.add('show')}
}
function showIdleWaitingHome(){
 const home=document.getElementById('home'); if(!home)return;
 document.getElementById('completeFlow')?.remove();document.getElementById('reachFlow')?.remove();document.getElementById('acceptedPop')?.remove();document.getElementById('modal')?.remove();document.getElementById('np')?.remove();
 clearTimeout(window.dhsRequestTimer);clearInterval(window.dhsRequestCountdown);try{stopRouteBike?.()}catch(e){};try{window.dhsRouteMap?.remove()}catch(e){};window.dhsRouteMap=null;
 ['routeActionPanel','arrivalActions','routeNavBanner','routePath'].forEach(id=>document.getElementById(id)?.style.setProperty('display','none','important'));
 document.querySelectorAll('#homeMap .routeLegacyActions,#homeMap .partnerMapJobCard,#homeMap .partnerMapTools').forEach(e=>e.style.setProperty('display','none','important'));
 document.querySelector('#homeMap .partnerMapOverlay')?.classList.remove('routeActive','requestActive');
 activeRouteJob=null; document.getElementById('idleWaitingHome')?.remove();
 const idle=document.createElement('div');idle.id='idleWaitingHome';idle.className='idleWaitingHome';document.body.classList.add('idleHomeActive');
 idle.innerHTML='<div class="idleWaitingBox"><div class="idleDhs"><span>D</span><b>H</b><span>S</span></div><div class="idleSpinner"><i></i></div><h2>DHS Partner</h2><div class="idleTitle">Start Earning</div><p>Waiting for bookings</p></div>';
 home.appendChild(idle);[...home.children].forEach(e=>{if(e.id!=='idleWaitingHome')e.classList.add('idleHidden')});document.querySelectorAll('.top,.bottom').forEach(e=>e.classList.add('idleHidden'));
}
function hideIdleWaitingHome(){
 const home=document.getElementById('home');
 const idle=document.getElementById('idleWaitingHome');
 if(idle)idle.remove();
 document.body.classList.remove('idleHomeActive');
 if(home)[...home.children].forEach(el=>el.classList.remove('idleHidden'));
}

// Always restore the exact normal Home screen used when the Partner app first opens.
// This is intentionally different from the full-screen "Start Earning" waiting overlay.
function resetToInitialHomeScreen(){
 try{
  document.getElementById('idleWaitingHome')?.remove();
  document.getElementById('completeFlow')?.remove();
  document.getElementById('reachFlow')?.remove();
  document.getElementById('jobCompleteSuccess')?.remove();
  document.getElementById('acceptedPop')?.remove();
  document.getElementById('np')?.remove();
  document.querySelectorAll('.modalBack,.notificationPop').forEach(el=>el.remove());
  document.body.classList.remove('idleHomeActive','liveMapOpen');
  const card=document.getElementById('mapCard');
  const map=document.getElementById('homeMap');
  card?.classList.remove('mapFullHost');
  map?.classList.remove('fullscreenMap');
  setHomeWaitingState(true);
  map?.classList.remove('requestActive','routeActive');
  document.querySelector('#homeMap .partnerMapOverlay')?.classList.remove('requestActive','routeActive');
  ['routeActionPanel','arrivalActions','routeNavBanner','routePath'].forEach(id=>document.getElementById(id)?.style.setProperty('display','none','important'));
  document.getElementById('routePath')?.style.removeProperty('animation');
  document.getElementById('routeActionPanel')?.classList.remove('completeBusy');
  document.getElementById('mapStatus')&&(document.getElementById('mapStatus').textContent='LIVE');
  document.getElementById('mapLiveStatus')&&(document.getElementById('mapLiveStatus').textContent='LIVE');
  stopRouteBike?.();
  activeRouteJob=null;
  currentPage='home';
  document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));
  document.getElementById('home')?.classList.add('active');
  document.querySelectorAll('.bottom button').forEach(x=>x.classList.remove('active'));
  document.querySelector('[data-page="home"]')?.classList.add('active');
  document.querySelectorAll('.top,.bottom').forEach(e=>{e.classList.remove('idleHidden');e.style.removeProperty('display')});
  const home=document.getElementById('home');
  if(home)[...home.children].forEach(el=>el.classList.remove('idleHidden'));
  requestAnimationFrame(()=>{document.documentElement.scrollTop=0;document.body.scrollTop=0;window.scrollTo(0,0)});
 }catch(e){console.warn('home reset',e)}
}
function showCompleteFlow(id){
 document.getElementById('completeFlow')?.remove();
 document.body.insertAdjacentHTML('beforeend',`<div class="complete-flow" id="completeFlow"><div class="flow-box"><div id="flowInner"><div class="flow-spinner"></div><h2>Saving Work…</h2><p>Please wait 3 seconds.</p></div></div></div>`);
 setTimeout(()=>{
   const el=document.getElementById('flowInner');
   if(el)el.innerHTML='<div class="flow-check">✓</div><h2>Successfully Work Completed</h2><p>Your work has been saved successfully.</p>';
 },3000);
 setTimeout(()=>{
   document.getElementById('completeFlow')?.remove();
   document.getElementById('arrivalActions')&&(document.getElementById('arrivalActions').style.display='none');
   document.getElementById('routePath')&&(document.getElementById('routePath').style.display='none');
   document.getElementById('mapStatus')&&(document.getElementById('mapStatus').textContent='LIVE');
   document.getElementById('mapLiveStatus')&&(document.getElementById('mapLiveStatus').textContent='LIVE');
   resetToInitialHomeScreen();
   renderJobs();
   renderEarnings();
 },6000);
}
async function saveWorkProof(id){const btn=document.getElementById('uploadCompleteBtn');try{if(!workPhotoFiles.length&&!workVideoFiles.length)throw Error('Please take at least one photo or video');if(btn){btn.disabled=true;btn.textContent='Uploading…'}let photoUrls=[],videoUrls=[];for(let i=0;i<workPhotoFiles.length;i++){if(btn)btn.textContent=`Uploading photo ${i+1}/${workPhotoFiles.length}…`;photoUrls.push(await uploadFile(workPhotoFiles[i],user.uid,'work_photo_'+id))}for(let i=0;i<workVideoFiles.length;i++){if(btn)btn.textContent=`Uploading video ${i+1}/${workVideoFiles.length}…`;videoUrls.push(await uploadFile(workVideoFiles[i],user.uid,'work_video_'+id))}let job=jobs.find(x=>x.id===id)||{},elapsed=workSeconds||0;let proofData={partnerId:user.uid,workerid:profile?.id||user.uid,partnerName:first(profile,['name'],user.email),partnerEmail:user.email,bookingId:id,customerName:first(job,['costumername','customerName'],'Customer'),phone:first(job,['costumerphone','customerPhone','phone'],''),address:first(job,['costumerAddress','customerAddress','address'],''),service:first(job,['service'],'Service'),photoUrls,videoUrls,photoUrl:photoUrls[0]||'',videoUrl:videoUrls[0]||'',photoCount:photoUrls.length,videoCount:videoUrls.length,workSeconds:elapsed,status:'COMPLETED',createdAt:firebase.firestore.FieldValue.serverTimestamp()};let ref=await db.collection('partnerWorkData').add(proofData);await db.collection('partnerJobs').doc(id).set({Stuts:'COMPLETED',partnerStatus:'COMPLETED',bookingStatus:'COMPLETED',workProofId:ref.id,workPhotos:photoUrls,workVideos:videoUrls,hasWorkPhoto:photoUrls.length>0,hasWorkVideo:videoUrls.length>0,workSeconds:elapsed,UpdatedAt:firebase.firestore.FieldValue.serverTimestamp(),updatedBy:user.uid},{merge:true});try{await db.collection('bookings').doc(id).set({partnerStatus:'COMPLETED',bookingStatus:'COMPLETED',workProofId:ref.id,workPhotos:photoUrls,workVideos:videoUrls,workSeconds:elapsed,UpdatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true})}catch(e){}await syncPartnerAdmin({lastAction:'COMPLETE_JOB',currentBookingId:id,currentBookingStatus:'COMPLETED',lastWorkProofId:ref.id,workPhotos:photoUrls,workVideos:videoUrls,workSeconds:elapsed});closeModal();showCompleteFlow(id)}catch(e){if(btn){btn.disabled=false;btn.textContent='Complete Work'}toast(e.message||'Work proof upload failed')}}
function openMapById(id){let j=jobs.find(x=>x.id===id);if(j){activeRouteJob=j;setMapJob(j);go('home',document.querySelector('[data-page="home"]'));if(['ON_THE_WAY','WORKING','ARRIVED'].includes(jobState(j)))startRouteAnimation(j)}}
function openMap(j){if(j){activeRouteJob=j;setMapJob(j)}go('home',document.querySelector('[data-page="home"]'));if(j&&['ON_THE_WAY','WORKING'].includes(jobState(j)))startRouteAnimation(j)}
function jobDate(j){let ms=Number(first(j,['completedAtMs'],0));if(ms)return new Date(ms);let v=first(j,['completedAt','acceptedAt','createdAt','date','completedDate','acceptedDate'],null);if(v?.toDate)return v.toDate();if(v?.seconds)return new Date(v.seconds*1000);let d=new Date(v||0);return isNaN(d)?null:d}
function jobAmount(j){return Number(first(j,['amount','total','payment','earning','partnerEarning'],0))||0}
function moneySigned(n){return money(n)}
function localDayKey(d=new Date()){const x=d instanceof Date?d:new Date(d);return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`}
function paymentDayKey(p){let v=first(p,['paymentDate','paidDate','date'],null);if(typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v))return v;if(v?.toDate)return localDayKey(v.toDate());if(v?.seconds)return localDayKey(new Date(v.seconds*1000));let d=new Date(v||0);if(!isNaN(d))return localDayKey(d);let c=p?.createdAt;return c?.toDate?localDayKey(c.toDate()):c?.seconds?localDayKey(new Date(c.seconds*1000)):''}
function successfulPartnerPayments(){return (payments||[]).filter(p=>String(first(p,['paymentStatus','status'],'')).toUpperCase()==='SUCCESS').sort((a,b)=>{const da=paymentDayKey(a),db=paymentDayKey(b);return db.localeCompare(da)})}
function paymentDaySummary(key){const rows=successfulPartnerPayments().filter(p=>paymentDayKey(p)===key);return {rows,count:rows.length,total:rows.reduce((n,p)=>n+Number(first(p,['amount','total','paidAmount'],0)||0),0)}}
function weekStartFor(d=new Date()){const x=new Date(d.getFullYear(),d.getMonth(),d.getDate());x.setDate(x.getDate()-x.getDay());return x}
function renderEarnings(){const done=jobs.filter(j=>assignedToMe(j)&&jobState(j)==='COMPLETED');const today=paymentDaySummary(localDayKey());const ws=weekStartFor(new Date());const weekKeys=[];for(let i=0;i<7;i++){const d=new Date(ws);d.setDate(ws.getDate()+i);weekKeys.push(localDayKey(d))}const weekRows=successfulPartnerPayments().filter(p=>weekKeys.includes(paymentDayKey(p)));const weekTotal=weekRows.reduce((n,p)=>n+Number(first(p,['amount','total','paidAmount'],0)||0),0);const cashTotal=successfulPartnerPayments().filter(p=>{const m=String(first(p,['method','mode','paymentMethod','paymentType'],'Cash'));return /^cash$/i.test(m)||/cash|cod/i.test(m)}).reduce((n,p)=>n+Number(first(p,['amount','total','paidAmount'],0)||0),0);const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v};set('statJobs',done.length);set('statPay',money(today.total));set('statWeek',money(weekTotal));set('statBills',bills.length);set('walletCashTotal',money(cashTotal));const cl=document.querySelector('#completedList');if(cl)cl.innerHTML=done.slice().sort((a,b)=>(jobDate(b)?.getTime()||0)-(jobDate(a)?.getTime()||0)).map(j=>`<div class="earnDetailCard"><div class="earnDetailRow"><div><b>${esc(first(j,['costumername','customerName','customer'],'Customer'))}</b><div class="muted">${esc(first(j,['service','serviceType'],'Service'))}</div></div><strong>${money(jobAmount(j))}</strong></div><div class="muted" style="margin-top:6px">📍 ${esc(first(j,['costumerAddress','customerAddress','address'],'Address not available'))}</div><div class="leadTime">Job Time: ${formatWorkDuration(first(j,['workDurationSeconds','workSeconds'],0))} • ${formatLeadTime(jobDate(j)||new Date())}</div></div>`).join('')||'<div class="card empty">No completed jobs yet.</div>'}
function earningPopupIcon(name){const paths={back:'<path d="M19 12H5"/><path d="m12 19-7-7 7-7"/>',brief:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M3 11h18"/>',pin:'<path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',user:'<circle cx="12" cy="8" r="3.5"/><path d="M5 20c.7-3.3 3.1-5 7-5s6.3 1.7 7 5"/>',rupee:'<path d="M7 4h10M7 8h10M8 4c5 0 7 2 7 5s-2 5-7 5h-1l7 6"/>',calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>'};return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name]||paths.brief}</svg>`}
function paymentPopupCard(p){const customer=first(p,['customerName','costumername','customer'],'Customer');const service=first(p,['service','serviceType'],'Service');const address=first(p,['address','costumerAddress','customerAddress'],'Address not available');const amount=Number(first(p,['amount','total','paidAmount'],0)||0);const method=String(first(p,['method','mode','paymentMethod','paymentType'],'Cash'));const payment=/upi|online|razorpay|bank/i.test(method)?'Online (UPI)':'Cash';const invoice=first(p,['invoice','billId'],'—');const time=first(p,['paymentTime'], '');return `<div class="earningPopupCustomer"><div class="epTop"><div class="epAvatar">${earningPopupIcon('user')}</div><div class="epName"><b>${esc(customer)}</b><small>${esc(service)}</small></div><strong>${money(amount)}</strong></div><div class="epLine">${earningPopupIcon('brief')}<span><b>Service</b>${esc(service)}</span></div><div class="epLine">${earningPopupIcon('pin')}<span><b>Customer Address</b>${esc(address)}</span></div><div class="epLine">${earningPopupIcon('rupee')}<span><b>Payment</b>${esc(payment)} • ${money(amount)}</span></div><div class="epLine">${earningPopupIcon('brief')}<span><b>Bill</b>${esc(invoice)}</span></div>${time?`<div class="epDate">Paid: ${esc(time)}</div>`:''}</div>`}
function openEarningDetail(type){if(type==='bills'){let items=bills.slice().sort((a,b)=>(ts(b.createdAt||b.updatedAt)-ts(a.createdAt||a.updatedAt)));if(!items.length)items=[null];document.body.insertAdjacentHTML('beforeend',`<div class="earningPopupBack" id="earningPopup" onclick="if(event.target.id==='earningPopup')closeEarningPopup()"><div class="earningPopup"><div class="earningPopupHead"><button class="earningBack" onclick="closeEarningPopup()">${earningPopupIcon('back')}</button><div><b>Total Bills</b><small>${items[0]?'All generated customer bills':'No bills generated yet'}</small></div><span class="earningHeadIcon">${earningPopupIcon('rupee')}</span></div><div class="earningPopupScroll">${items.map((b,i)=>billDetailCard(b,i)).join('')}</div></div></div>`);return}
if(type==='completed'){let items=jobs.filter(j=>jobState(j)==='COMPLETED').sort((a,b)=>(jobDate(b)?.getTime()||0)-(jobDate(a)?.getTime()||0));document.body.insertAdjacentHTML('beforeend',`<div class="earningPopupBack" id="earningPopup" onclick="if(event.target.id==='earningPopup')closeEarningPopup()"><div class="earningPopup"><div class="earningPopupHead"><button class="earningBack" onclick="closeEarningPopup()">${earningPopupIcon('back')}</button><div><b>Total Jobs Completed</b><small>${items.length} completed jobs</small></div><span class="earningHeadIcon">${earningPopupIcon('brief')}</span></div><div class="earningPopupScroll">${items.length?items.map((j,i)=>earningPopupCard(j,'completed',i)).join(''):'<div class="earningEmpty">No completed jobs yet.</div>'}</div></div></div>`);return}
if(type==='total'){const key=localDayKey();const s=paymentDaySummary(key);const d=new Date();const title=d.toLocaleDateString('en-IN',{weekday:'long',day:'2-digit',month:'long',year:'numeric'});document.body.insertAdjacentHTML('beforeend',`<div class="earningPopupBack" id="earningPopup" onclick="if(event.target.id==='earningPopup')closeEarningPopup()"><div class="earningPopup"><div class="earningPopupHead"><button class="earningBack" onclick="closeEarningPopup()">${earningPopupIcon('back')}</button><div><b>Total Earning</b><small>Today only • ${esc(title)}</small></div><span class="earningHeadIcon">${earningPopupIcon('rupee')}</span></div><div class="earningPopupScroll"><div class="earnHero"><b>${money(s.total)}</b><span>${s.count} paid job${s.count===1?'':'s'} today</span></div>${s.rows.length?s.rows.map(paymentPopupCard).join(''):'<div class="earningEmpty">No payment received today.<br>Tomorrow this box automatically starts from ₹0. Today’s earning remains saved in This Week Earning.</div>'}</div></div></div>`);return}
if(type==='week'){openWeeklyEarningCalendar(0);return}}
function openWeeklyEarningCalendar(offset=0){const base=weekStartFor(new Date());base.setDate(base.getDate()+offset*7);const days=[];for(let i=0;i<7;i++){const d=new Date(base);d.setDate(base.getDate()+i);const k=localDayKey(d),s=paymentDaySummary(k);days.push({d,k,s})}const total=days.reduce((n,x)=>n+x.s.total,0);const firstDay=days[0].d,lastDay=days[6].d;document.getElementById('modal')?.remove();document.body.insertAdjacentHTML('beforeend',`<div class="earningPopupBack" id="earningPopup" onclick="if(event.target.id==='earningPopup')closeEarningPopup()"><div class="earningPopup"><div class="earningPopupHead"><button class="earningBack" onclick="closeEarningPopup()" aria-label="Back">${earningPopupIcon('back')}</button><div><b>This Week Earning</b><small>${firstDay.toLocaleDateString('en-IN',{day:'2-digit',month:'short'})} – ${lastDay.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</small></div><span class="earningHeadIcon">${earningPopupIcon('calendar')}</span></div><div class="earningPopupScroll"><div class="earnHero"><b>${money(total)}</b><span>Weekly earning</span></div><div class="weekCalendar">${days.map(x=>`<button class="weekDay ${x.k===localDayKey()?'today':''}" onclick="openEarningDate('${x.k}',${offset})"><b>${x.d.toLocaleDateString('en-IN',{weekday:'short'})}</b><span>${x.d.getDate()} ${x.d.toLocaleDateString('en-IN',{month:'short'})}</span><strong>${money(x.s.total)}</strong><small>${x.s.count} paid job${x.s.count===1?'':'s'}</small></button>`).join('')}</div><div class="weekNav"><button class="btn white" onclick="openWeeklyEarningCalendar(${offset-1})">‹ Previous Week</button><button class="btn white" onclick="openWeeklyEarningCalendar(${offset+1})">Next Week ›</button></div></div></div></div>`)}
function openEarningDate(key,offset=0){const s=paymentDaySummary(key),d=new Date(key+'T12:00:00'),title=d.toLocaleDateString('en-IN',{weekday:'long',day:'2-digit',month:'long',year:'numeric'});document.getElementById('modal')?.remove();document.getElementById('earningPopup')?.remove();document.body.insertAdjacentHTML('beforeend',`<div class="earningPopupBack" id="earningPopup" onclick="if(event.target.id==='earningPopup')closeEarningPopup()"><div class="earningPopup"><div class="earningPopupHead"><button class="earningBack" onclick="openWeeklyEarningCalendar(${offset})" aria-label="Back">${earningPopupIcon('back')}</button><div><b>${esc(title)}</b><small>${s.count} paid job${s.count===1?'':'s'} on this date</small></div><span class="earningHeadIcon">${earningPopupIcon('calendar')}</span></div><div class="earningPopupScroll"><div class="earnHero"><b>${money(s.total)}</b><span>Daily earning</span></div>${s.rows.length?s.rows.map(paymentPopupCard).join(''):'<div class="earningEmpty">No payment received on this date.</div>'}</div></div></div>`)}
function closeEarningPopup(){document.getElementById('earningPopup')?.remove();closeModal?.()}
function listenPayments(){if(window.partnerPaymentUnsub)window.partnerPaymentUnsub();if(!user?.uid)return;window.partnerPaymentUnsub=db.collection('payments').where('partnerId','==',user.uid).onSnapshot(s=>{payments=s.docs.map(d=>({id:d.id,...d.data()}));renderEarnings()},e=>{payments=[];console.warn('payment listener',e);renderEarnings()})}
function earningPopupCard(j,kind,index){const demo=!j;const customer=demo?'Ranjan':first(j,['costumername','customerName','customer'],'Customer');const service=demo?'Plumber':first(j,['service','serviceType'],'Service');const address=demo?'Jaime Nagar':first(j,['costumerAddress','customerAddress','address'],'Address not available');const phone=demo?'Not available':first(j,['costumerphone','customerPhone','phone'],'Not available');const amount=demo?0:jobAmount(j);const st=demo?'ACCEPTED':jobState(j);const date=demo?'04 Sep, 03:18 am':formatLeadTime(first(j,['createdAt','sentAt','assignedAt','date'],Date.now()));return `<div class="earningPopupCustomer"><div class="epTop"><div class="epAvatar">${earningPopupIcon('user')}</div><div class="epName"><b>${esc(customer)}</b><small>${esc(service)}</small></div><strong>${money(amount)}</strong></div><div class="epLine">${earningPopupIcon('pin')}<span><b>Customer Address</b>${esc(address)}</span></div><div class="epLine">${earningPopupIcon('brief')}<span><b>Booking Status</b>${esc(st.replaceAll('_',' '))}</span></div><div class="epLine">${earningPopupIcon('rupee')}<span><b>Job Payment</b>${money(amount)}</span></div><div class="epLine">${earningPopupIcon('brief')}<span><b>Job Completion Time</b>${esc(formatWorkDuration(first(j||{},['workDurationSeconds'],0)))}</span></div><div class="epDate">${esc(date)}</div><div class="completed-actions"><button class="btn completed-view" onclick="${demo?'closeEarningPopup()':`openEarningJob('${esc(j.id)}')`}">View Booking Details</button>${demo?'':`<button class="btn completed-generate" onclick="generateBillFromJob('${esc(j.id)}')">Generate Bill</button>`}</div></div>`}
function openEarningJob(id){const j=jobs.find(x=>x.id===id);if(j){closeEarningPopup();setTimeout(()=>showAcceptedPopup(j),80)}}
function billDetailCard(b,i){if(!b)return '<div class="earningEmpty">No bills generated yet.</div>';const customer=first(b,['customerName','costumername','customer'],'Customer');const service=first(b,['service','serviceType'],'Service');const address=first(b,['address','costumerAddress','customerAddress'],'Address not available');const amount=Number(first(b,['total','amount'],0));const method=String(first(b,['paymentMethod','paymentType'],'Cash'));const status=String(first(b,['paymentStatus','status'],'PENDING'));const online=['UPI','UPI QR','Razorpay','Bank Transfer','Online'].includes(method)||/upi|online|razorpay|bank/i.test(method);const payment=online?'Online (UPI)':'Cash';const details=(b.items||[]).map(x=>[x.description,x.details].filter(Boolean).join(' — ')).filter(Boolean).join(' • ')||'Service bill';return `<div class="billDetailCard" data-bill-id="${esc(b.id)}"><div class="billDetailTop"><div><b>${esc(customer)}</b><small>${esc(service)}</small></div><strong>${money(amount)}</strong></div><div class="billDetailLine">🔧 ${esc(details)}</div><div class="billDetailLine">📍 ${esc(address)}</div><div class="billDetailBottom"><span>Payment: <b>${esc(payment)}</b></span><span>${esc(status)}</span></div><button class="btn white full mt8" onclick="toggleInlineBill('${esc(b.id)}',this)">View Bill</button><div class="bill-inline-preview" id="inlineBill_${esc(b.id)}"></div></div>`}
function formatWeekLabel(d){return d.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})+' week'}
function earningCard(j,accepted=false){return `<div class="earnDetailCard"><div class="earnDetailRow"><div><b>${esc(first(j,['costumername','customerName','customer'],'Customer'))}</b><div class="muted">${esc(first(j,['service','serviceType'],'Service'))}</div></div><strong>${money(jobAmount(j))}</strong></div><div class="muted" style="margin-top:6px">📍 ${esc(first(j,['costumerAddress','customerAddress','address'],'Address not available'))}</div><div class="leadTime">${jobState(j)} • ${formatLeadTime(jobDate(j)||new Date())}</div>${accepted?`<div class="muted" style="margin-top:5px">Accepted lead</div>`:''}</div>`}

let bills=[],billUnsub=null,itemNo=0,activePayment=null;
const DHS_UPI_ID='9718448382@axl',DHS_PAYEE='Delhi Home Service';
function listenBills(){if(billUnsub)billUnsub();let q=db.collection('bills').where('partnerId','==',user.uid);billUnsub=q.onSnapshot(s=>{bills=s.docs.map(d=>({id:d.id,...d.data()}));renderBills();renderEarnings()},e=>console.warn('bill listener',e))}
function invoiceFromBillData(b){const g=id=>document.getElementById(id);if(!g)return;g('pName').textContent=first(b,['customerName','costumername','customer'],'—');g('pPhone').textContent=first(b,['phone','customerPhone','costumerphone'],'—');g('pAddress').textContent=first(b,['address','costumerAddress','customerAddress'],'—');g('pService').textContent=first(b,['service','serviceType'],'—');g('pInvoice').textContent=first(b,['invoice'],'DHS-0000');g('pDate').textContent=first(b,['date'],'');const items=Array.isArray(b.items)?b.items:[];g('pItems').innerHTML=items.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.description||'Service')}</td><td>${esc(x.details||'')}</td><td>${Number(x.qty||1)}</td><td>${money(Number(x.rate||0)).replace('₹','')}</td><td>${money(Number(x.amount||((Number(x.qty)||1)*(Number(x.rate)||0)))).replace('₹','')}</td></tr>`).join('');const sub=Number(first(b,['subtotal'],items.reduce((a,x)=>a+(Number(x.qty)||1)*(Number(x.rate)||0),0)));const d=Number(first(b,['discount'],0));const total=Number(first(b,['total','amount'],Math.max(0,sub-d)));g('pSubtotal').textContent=money(sub);g('pDiscount').textContent='- '+money(d);g('pTotal').textContent=money(total);g('pWords').textContent='('+numberWords(total)+' Only)';g('pStatus').textContent='Payment Status: '+first(b,['paymentStatus','status'],'PAID');g('pNotes').innerHTML='';String(first(b,['notes'],'All work has been completed successfully.')).split(/\r?\n/).filter(Boolean).forEach(v=>{let li=document.createElement('li');li.textContent=v.replace(/^•\s*/,'');g('pNotes').appendChild(li)});}
function billInvoiceClone(b){invoiceFromBillData(b);const src=document.getElementById('invoice');if(!src)return '';const clone=src.cloneNode(true);clone.removeAttribute('id');return clone.outerHTML}
function toggleInlineBill(id,btn){const box=document.getElementById('inlineBill_'+id);if(!box)return;if(box.classList.contains('open')){box.classList.remove('open');box.innerHTML='';btn.textContent='View Bill';return}box.classList.add('open');box.innerHTML='<div class="bill-inline-loading">Loading bill…</div>';btn.textContent='Hide Bill';setTimeout(()=>{const b=bills.find(x=>String(x.id)===String(id));if(!b){box.innerHTML='<div class="bill-inline-loading">Bill not found</div>';return}box.innerHTML='<div class="bill-inline-frame">'+billInvoiceClone(b)+'</div><div class="bill-inline-tools"><button class="bill-inline-zoom" onclick="openBillZoom(\''+esc(b.id)+'\')">🔍 Zoom Bill</button><button class="bill-inline-edit" onclick="closeEarningPopup();viewBill(\''+esc(b.id)+'\')">Edit Bill</button></div>';box.scrollIntoView({behavior:'smooth',block:'nearest'})},450)}
function openBillZoom(id){const b=bills.find(x=>String(x.id)===String(id));if(!b)return;document.getElementById('billZoomOverlay')?.remove();const html=billInvoiceClone(b);document.body.insertAdjacentHTML('beforeend',`<div class="bill-zoom-back" id="billZoomOverlay"><button class="bill-zoom-close" onclick="document.getElementById('billZoomOverlay')?.remove()">×</button><div class="bill-zoom-label">${esc(first(b,['customerName','customer'],'Customer'))} • Bill</div><div class="bill-zoom-shell">${html}</div></div>`)}
async function generateBillFromJob(id){let j=jobs.find(x=>String(x.id)===String(id));if(!j){try{const snap=await db.collection('partnerJobs').doc(id).get();if(snap.exists)j={id:snap.id,...snap.data()}}catch(e){}}if(!j){toast('Booking not found');return}closeEarningPopup();go('bills',document.querySelector('[data-page=\"bills\"]'));const g=id=>document.getElementById(id);const customer=first(j,['costumername','customerName','customer'],'Customer');const phone=first(j,['costumerphone','customerPhone','phone'],'');const address=first(j,['costumerAddress','customerAddress','address'],'');const service=first(j,['service','serviceType'],'');const amount=Number(jobAmount(j)||0);g('name').value=customer;g('phone').value=phone;g('address').value=address;g('service').value=service;g('invoiceNo').value='DHS-'+Date.now().toString().slice(-6);g('date').value=new Date().toISOString().slice(0,10);g('discount').value=0;g('paymentStatus').value='PENDING';g('paymentMethod').value='Cash';g('items').innerHTML='';itemNo=0;addItem(service||'Service','',1,amount);generate(false);window.scrollTo({top:0,behavior:'smooth'});setTimeout(()=>g('name')?.focus(),250)}
function renderBills(){const el=document.querySelector('#billList');if(!el)return;el.innerHTML=bills.map(b=>`<div class="card"><div class="row"><div class="grow"><b>${esc(first(b,['customerName','costumername'],'Customer'))}</b><div class="muted">${esc(first(b,['service'],'Service'))} • ${esc(first(b,['paymentMethod','paymentType'],'Cash'))} • ${esc(first(b,['paymentStatus','status'],'PENDING'))}</div></div><strong>${money(first(b,['total','amount'],0))}</strong></div><button class="btn white full mt8" onclick='viewBill(${JSON.stringify(b.id)})'>View / Edit Bill</button></div>`).join('')||'<div id="billListEmpty" class="card empty">No bills yet. Complete a job to create the first bill.</div>'}
function addItem(desc='',details='',qty=1,rate=0){itemNo++;const x=document.createElement('div');x.className='bill-item-row';x.innerHTML=`<div>${itemNo}</div><input class="desc" value="${esc(desc)}" placeholder="Description" oninput="calc()"><input class="details" value="${esc(details)}" placeholder="Details"><input class="qty" type="number" value="${qty}" min="1" oninput="calc()"><input class="rate" type="number" value="${rate}" min="0" oninput="calc()"><div class="bill-amount">₹0.00</div><button class="bill-del" onclick="this.parentElement.remove();renumberBillItems();calc()">×</button>`;document.getElementById('items').appendChild(x);calc()}
function renumberBillItems(){[...document.querySelectorAll('#items .bill-item-row')].forEach((x,i)=>x.children[0].textContent=i+1);itemNo=document.querySelectorAll('#items .bill-item-row').length}
function calc(){let sub=0;document.querySelectorAll('#items .bill-item-row').forEach(x=>{let q=+x.querySelector('.qty').value||0,r=+x.querySelector('.rate').value||0,a=q*r;sub+=a;x.querySelector('.bill-amount').textContent=money(a)});let d=+document.getElementById('discount').value||0,total=Math.max(0,sub-d);document.getElementById('subtotal').textContent=money(sub);document.getElementById('total').textContent=money(total);return total}
function numberWords(n){n=Math.round(n);if(!n)return'Rupees Zero';const o=['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'],t=['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];let two=x=>x<20?o[x]:t[Math.floor(x/10)]+(x%10?' '+o[x%10]:''),three=x=>x>=100?o[Math.floor(x/100)]+' Hundred'+(x%100?' '+two(x%100):''):two(x);let s='';if(n>=10000000){s+=three(Math.floor(n/10000000))+' Crore ';n%=10000000}if(n>=100000){s+=three(Math.floor(n/100000))+' Lakh ';n%=100000}if(n>=1000){s+=three(Math.floor(n/1000))+' Thousand ';n%=1000}if(n)s+=three(n);return'Rupees '+s.trim()}
async function generate(save=true){let sub=0,items=[];document.querySelectorAll('#items .bill-item-row').forEach((x,i)=>{let q=+x.querySelector('.qty').value||0,r=+x.querySelector('.rate').value||0,a=q*r;sub+=a;items.push({description:x.querySelector('.desc').value.trim(),details:x.querySelector('.details').value.trim(),qty:q,rate:r,amount:a})});let d=+document.getElementById('discount').value||0,total=Math.max(0,sub-d);const g=id=>document.getElementById(id);g('pName').textContent=g('name').value||'—';g('pPhone').textContent=g('phone').value||'—';g('pAddress').textContent=g('address').value||'—';g('pService').textContent=g('service').value||'—';g('pInvoice').textContent=g('invoiceNo').value||'DHS-0000';g('pDate').textContent=g('date').value||'';g('pItems').innerHTML=items.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.description)}</td><td>${esc(x.details)}</td><td>${x.qty}</td><td>${money(x.rate).replace('₹','')}</td><td>${money(x.amount).replace('₹','')}</td></tr>`).join('');g('pSubtotal').textContent=money(sub);g('pDiscount').textContent='- '+money(d);g('pTotal').textContent=money(total);g('total').textContent=money(total);g('subtotal').textContent=money(sub);g('pWords').textContent='('+numberWords(total)+' Only)';g('pStatus').textContent='Payment Status: '+g('paymentStatus').value;g('pNotes').innerHTML='';(g('notes').value||'All work has been completed successfully.').split(/\r?\n/).filter(Boolean).forEach(v=>{let li=document.createElement('li');li.textContent=v.replace(/^•\s*/,'');g('pNotes').appendChild(li)});
 if(save&&g('name').value.trim()){let inv=g('invoiceNo').value,existing=bills.find(x=>x.invoice===inv);let data={invoice:inv,partnerId:user.uid,workerid:profile?.id||user.uid,partnerName:first(profile,['name'],user.email),partnerEmail:user.email,customerName:g('name').value,phone:g('phone').value,address:g('address').value,service:g('service').value,items,subtotal:sub,discount:d,total,date:g('date').value,notes:g('notes').value,paymentStatus:g('paymentStatus').value,paymentMethod:g('paymentMethod').value,updatedAt:firebase.firestore.FieldValue.serverTimestamp()};try{if(existing){await db.collection('bills').doc(existing.id).set(data,{merge:true})}else{data.createdAt=firebase.firestore.FieldValue.serverTimestamp();const ref=await db.collection('bills').add(data);data.id=ref.id;bills.push({...data,createdAt:{seconds:Math.floor(Date.now()/1000)}})}await syncPartnerAdmin({lastAction:'CREATE_BILL',lastBillId:existing?.id||data.id,billInvoice:inv,billTotal:total,billPaymentStatus:g('paymentStatus').value})}catch(e){console.warn(e);toast('Bill save failed: '+e.message)}}return {invoice:g('invoiceNo').value,customerName:g('name').value,phone:g('phone').value,address:g('address').value,service:g('service').value,amount:total,date:g('date').value,items,subtotal:sub,discount:d,notes:g('notes').value}}
function resetBill(render=true){const g=id=>document.getElementById(id);if(!g('name'))return;g('name').value=g('phone').value=g('address').value=g('service').value='';g('invoiceNo').value='DHS-'+Date.now().toString().slice(-6);g('date').value=new Date().toISOString().slice(0,10);g('discount').value=0;g('paymentStatus').value='PENDING';g('paymentMethod').value='Cash';g('notes').value='• All work has been completed successfully.\n• Please ensure payment is made upon completion of service.\n• Thank you for choosing Delhi Home Service.';g('items').innerHTML='';itemNo=0;addItem('Service','',1,0);if(render)generate(false)}
function newBill(){go('bills',document.querySelector('[data-page="bills"]'));resetBill(true);window.scrollTo({top:0,behavior:'smooth'})}
async function viewBill(id){const b=bills.find(x=>x.id===id);if(!b)return;go('bills',document.querySelector('[data-page="bills"]'));document.getElementById('name').value=b.customerName||'';document.getElementById('phone').value=b.phone||'';document.getElementById('invoiceNo').value=b.invoice||'';document.getElementById('date').value=b.date||'';document.getElementById('address').value=b.address||'';document.getElementById('service').value=b.service||'';document.getElementById('discount').value=b.discount||0;document.getElementById('paymentStatus').value=b.paymentStatus||'PENDING';document.getElementById('paymentMethod').value=b.paymentMethod||'Cash';document.getElementById('notes').value=b.notes||'';document.getElementById('items').innerHTML='';itemNo=0;(b.items||[]).forEach(x=>addItem(x.description||'',x.details||'',x.qty||1,x.rate||0));if(!(b.items||[]).length)addItem('Service','',1,0);await generate(false);window.scrollTo({top:0,behavior:'smooth'})}
async function printBill(){
  try{
    await generate(false);
    const invoice=document.getElementById('invoice');
    if(!invoice){toast('Bill preview not found');return}

    // Android's native print bridge needs a complete HTML document. Passing only
    // invoice.outerHTML makes the print WebView lose the page CSS and can result
    // in a blank/blue print preview. Keep all current styles and use the same
    // invoice markup that is visible in the app.
    const styles=[...document.querySelectorAll('style')].map(s=>s.textContent||'').join('\n');
    const invoiceHtml=invoice.outerHTML;
    const printHtml=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DHS Bill</title><style>
${styles}
@page{size:A4;margin:0!important}
html,body{width:210mm!important;height:297mm!important;margin:0!important;padding:0!important;background:#fff!important;overflow:hidden!important}
body{display:block!important;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
body>*{display:none!important}
body>.dhs-invoice{display:block!important;visibility:visible!important;position:relative!important;box-sizing:border-box!important;width:210mm!important;height:297mm!important;min-height:297mm!important;margin:0!important;padding:12mm 7mm 8mm!important;border:0!important;transform:none!important;overflow:hidden!important;background:#fff!important;color:#111!important}
body>.dhs-invoice *{visibility:visible!important}
body>.dhs-invoice img{max-width:100%!important}
*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
</style>
<style id="dhs-home-live-box-restore-v3">
/* RESTORE HOME LIVE BOX TO THE ORIGINAL COMPACT DHS PARTNER DESIGN.
   Payment + chat systems are intentionally untouched. */
#home .mapCard{margin-top:12px!important;border-radius:22px!important;overflow:hidden!important;background:#fff!important;border:1px solid #dbe3ee!important;box-shadow:0 12px 28px rgba(6,27,70,.14)!important}
#home .mapCard>.mapHead{height:42px!important;box-sizing:border-box!important;padding:9px 12px!important;background:#fff!important;color:#10284d!important;border-bottom:0!important}
#home .mapCard>.mapHead b{font-size:13px!important;letter-spacing:1.8px!important}
#home .mapCard>.mapHead b span{color:#ff7a18!important}
#home .mapCard>.mapHead .badge{margin-left:auto!important;padding:5px 9px!important;font-size:8px!important;border-radius:999px!important;background:#e9f9ef!important;color:#15803d!important}
#home .partnerMapShell{height:286px!important;min-height:286px!important;background:linear-gradient(135deg,#f7faff,#eef4fb)!important;border-radius:0!important;box-shadow:none!important}
#homeMap.idleWaiting .partnerMapOverlay{inset:0!important;background:linear-gradient(135deg,#f7faff,#eaf1f9)!important;display:grid!important;place-items:center!important}
#homeMap.idleWaiting .idleEarningState{display:flex!important;min-height:100%!important;height:100%!important;box-sizing:border-box!important;padding:10px 14px 13px!important;gap:3px!important;justify-content:center!important;color:#102445!important}
#homeMap.idleWaiting .idleDhsBrand{font-size:13px!important;letter-spacing:2px!important;margin:0 0 2px!important;color:#10284d!important;align-self:stretch!important;text-align:left!important}
#homeMap.idleWaiting .idleDhsBrand span:nth-child(2){color:#ff7a18!important}
#homeMap.idleWaiting .idleDhsBrand em{font-size:7px!important;letter-spacing:2.5px!important;margin-left:4px!important}
#homeMap.idleWaiting .idleToolsOrbit{width:min(170px,58%)!important;height:auto!important;aspect-ratio:1/1!important;margin:0 auto 1px!important}
#homeMap.idleWaiting .idleToolsOrbit img{opacity:.92!important;filter:drop-shadow(0 7px 14px rgba(23,82,160,.18))!important}
#homeMap.idleWaiting .idleOrbitGlow{width:60%!important;height:60%!important}
#homeMap.idleWaiting #idleOfflineBadge{display:none!important}
#homeMap.idleWaiting #idleStateTitle{font-size:21px!important;line-height:1.1!important;margin:0!important;color:#10284d!important}
#homeMap.idleWaiting #idleStateText{font-size:11px!important;line-height:1.2!important;margin:0!important;color:#69758a!important;font-weight:700!important}
#homeMap.idleWaiting #idleOnlineCta{display:none!important}
#homeMap.idleWaiting .idleLoading{display:flex!important;gap:7px!important;margin-top:6px!important}
#homeMap.idleWaiting .idleLoading i{width:8px!important;height:8px!important}
@media(max-width:600px){#home .partnerMapShell{height:286px!important;min-height:286px!important}#homeMap.idleWaiting .idleToolsOrbit{width:160px!important}#homeMap.idleWaiting #idleStateTitle{font-size:20px!important}}
</style>
</head><body>${invoiceHtml}</body></html>`;

    if(window.Android&&typeof Android.printBill==='function'){
      // IMPORTANT: pass the complete document to MainActivity.PrintBridge.
      Android.printBill(printHtml);
      return;
    }

    // Browser fallback for builds where the native bridge is unavailable.
    const w=window.open('', '_blank');
    if(!w){toast('Please allow pop-ups to print the bill');return}
    w.document.open();
    w.document.write(printHtml);
    w.document.close();
    setTimeout(()=>{w.focus();w.print();},900);
  }catch(e){toast('Print failed: '+(e?.message||e))}
}
function downloadPDF(){printBill()}
async function payCash(){const data=await generate(true);if(!data.amount){toast('Bill total ₹0 hai');return}try{await db.collection('payments').add({billId:data.billId||data.invoice,invoice:data.invoice,partnerId:user.uid,workerid:profile?.id||user.uid,customerName:data.customerName,phone:data.phone,amount:data.amount,total:data.amount,method:'Cash',mode:'Cash',paymentStatus:'SUCCESS',date:data.date,paymentDate:new Date().toISOString().slice(0,10),paymentTime:new Date().toLocaleTimeString('en-IN'),createdAt:firebase.firestore.FieldValue.serverTimestamp()});const b=bills.find(x=>x.invoice===data.invoice);if(b)await db.collection('bills').doc(b.id).set({paymentStatus:'PAID',paymentMethod:'Cash',paidAmount:data.amount,paidAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});document.getElementById('paymentStatus').value='PAID';document.getElementById('paymentMethod').value='Cash';document.getElementById('pStatus').textContent='Payment Status: PAID';await syncPartnerAdmin({lastAction:'PAYMENT_SUCCESS',paymentInvoice:data.invoice,paymentAmount:data.amount,paymentMethod:'Cash'});showPartnerSuccess('Cash Payment Successfully','Cash payment '+money(data.amount)+' recorded.');renderEarnings()}catch(e){showPartnerSuccess('Payment Error',e.message||'Payment save failed')}}
async function payQR(){
  try{
    const data=await generate(false);
    if(!data?.amount){toast('Bill total ₹0 hai');return}
    const bill=bills.find(b=>String(b.invoice||'')===String(data.invoice||''));
    activePayment={invoice:data.invoice,amount:Number(data.amount),customerName:data.customerName||'Customer',phone:data.phone||'',date:data.date||new Date().toISOString().slice(0,10),billId:bill?.id||data.billId||''};
    showPartnerPaymentQr(activePayment);
  }catch(e){toast('QR open failed: '+(e?.message||e))}
}
function showPartnerPaymentQr(data){
  const amount=Number(data?.amount||0);
  if(!amount){toast('Payment amount enter karein');return}
  const invoice=data.invoice||'DHS-COD-'+Date.now().toString().slice(-6);
  const html=`<div class="modalHead"><button class="earningBack" onclick="closeModal()" aria-label="Back">${earningPopupIcon('back')}</button><div><h3 style="margin:0">UPI QR Payment</h3><small style="opacity:.8">Scan from customer phone</small></div></div><div class="codQrScreen"><div class="payment-amount">${money(amount)}</div><div id="partnerPaymentQr" class="qr-wrap bigQr"><div class="payment-loading">Loading QR…</div></div><div class="upi-id">UPI: ${esc(DHS_UPI_ID)}</div><div class="payment-note">Customer PhonePe / Google Pay / Paytm se scan kare aur PIN dal kar payment complete kare.</div><div class="codStep"><span>1</span> Customer scan + PIN kare</div><div class="codStep"><span>2</span> Partner app me Done dabaye</div><button class="pay-success-btn" onclick="markPartnerQrSuccess()">✓ Done — Payment Received</button><button class="pay-cancel-btn" onclick="closeModal()">Close</button></div>`;
  closeModal();
  showModal(html);
  window.setTimeout(()=>renderActivePaymentQr(invoice,amount),150);
}
function closeDhsPayment(){document.getElementById('dhsPayOverlay')?.remove();document.body.classList.remove('dhs-pay-open')}
function openDhsPaymentOverlay(inner){closeDhsPayment();document.body.classList.add('dhs-pay-open');document.body.insertAdjacentHTML('beforeend',`<div class="dhsPayOverlay" id="dhsPayOverlay">${inner}</div>`)}
function openCodPayment(){
  const list=bills.filter(b=>Number(first(b,['total','amount'],0))>0).slice().sort((a,b)=>ts(b.createdAt||b.updatedAt)-ts(a.createdAt||a.updatedAt));
  const latest=list[0];
  const latestAmount=latest?Number(first(latest,['total','amount'],0)):'';
  openDhsPaymentOverlay(`<div class="dhsPayHead"><button class="dhsPayBack" onclick="closeDhsPayment()" aria-label="Back"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg></button><div><h3>Pay COD</h3><small>Cash + UPI QR Payment</small></div></div><div class="dhsPayBody"><label class="dhsPayLabel">Enter Amount</label><input id="codAmount" class="dhsPayAmountInput" type="number" min="1" step="1" value="${latestAmount}" placeholder="₹2400" inputmode="numeric"><div class="dhsPayQuick"><button onclick="setCodQuick(500)">₹500</button><button onclick="setCodQuick(1000)">₹1000</button><button onclick="setCodQuick(1500)">₹1500</button><button onclick="setCodQuick(2000)">₹2000</button><button onclick="setCodQuick(2500)">₹2500</button><button onclick="document.getElementById('codAmount')?.focus()">Other</button></div><button class="dhsPayPrimary" onclick="showCodQr()">Pay</button><div class="dhsPayInfo"><b>How it works?</b>1. Enter amount and tap Pay.<br>2. Exact amount QR will be generated.<br>3. Customer scans with any UPI app.<br>4. After payment, tap Done.<br>5. Success popup appears for 3 seconds.</div></div>`)
}
function setCodQuick(amount){const el=document.getElementById('codAmount');if(el){el.value=amount;el.focus()}}
function showCodQr(){
  const amount=Number(document.getElementById('codAmount')?.value||0);
  if(!amount){toast('Payment amount enter karein');return}
  const invoice='DHS-COD-'+Date.now().toString().slice(-6);
  activePayment={invoice,amount,customerName:'COD Customer',phone:'',date:new Date().toISOString().slice(0,10),billId:''};
  showPartnerPaymentQr(activePayment);
}
function showPartnerPaymentQr(data){
  const amount=Number(data?.amount||0);if(!amount){toast('Payment amount enter karein');return}
  const invoice=data.invoice||('DHS-COD-'+Date.now().toString().slice(-6));
  const html=`<div class="dhsPayHead"><button class="dhsPayBack" onclick="closeDhsPayment()" aria-label="Back"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg></button><div><h3>Scan & Pay</h3><small>UPI QR Payment</small></div></div><div class="dhsPayBody center"><div class="dhsQrAmount">${money(amount)}</div><div class="dhsQrBox" id="partnerPaymentQr"><div class="payment-loading" style="color:#061b46">Loading QR…</div></div><div class="dhsPayHint">Ask customer to scan this QR using any UPI app and complete the payment.</div><div class="dhsUpiApps"><span>PhonePe</span><span>G Pay</span><span>Paytm</span><span>BHIM</span></div><div class="dhsWaiting"><span class="dhsWaitingDot"></span>Waiting for payment…</div><button class="dhsPayDone" onclick="markPartnerQrSuccess()">Done</button></div>`;
  openDhsPaymentOverlay(html);window.setTimeout(()=>renderActivePaymentQr(invoice,amount),120)
}
function renderActivePaymentQr(invoice,amount){
  const area=document.getElementById('partnerPaymentQr');if(!area||!activePayment)return;
  const uri='upi://pay?pa='+encodeURIComponent(DHS_UPI_ID)+'&pn='+encodeURIComponent(DHS_PAYEE)+'&am='+encodeURIComponent(Number(amount).toFixed(2))+'&cu=INR&tn='+encodeURIComponent('Bill '+invoice);
  area.innerHTML='';
  if(window.QRCode)new QRCode(area,{text:uri,width:280,height:280,correctLevel:QRCode.CorrectLevel.M});
  else area.innerHTML='<div style="padding:30px;color:#c00">QR library load nahi hui.</div>';
}

async function markPartnerQrSuccess(){if(!activePayment)return;const data=activePayment;try{await db.collection('payments').add({billId:data.billId||data.invoice,invoice:data.invoice,partnerId:user.uid,workerid:profile?.id||user.uid,customerName:data.customerName,phone:data.phone,amount:data.amount,total:data.amount,method:'UPI QR',mode:'UPI QR',paymentStatus:'SUCCESS',date:data.date,paymentDate:new Date().toISOString().slice(0,10),paymentTime:new Date().toLocaleTimeString('en-IN'),createdAt:firebase.firestore.FieldValue.serverTimestamp()});if(data.billId){const b=bills.find(x=>String(x.id)===String(data.billId));if(b)await db.collection('bills').doc(b.id).set({paymentStatus:'PAID',paymentMethod:'UPI',paidAmount:data.amount,paidAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true})}const ps=document.getElementById('paymentStatus');const pm=document.getElementById('paymentMethod');if(ps)ps.value='PAID';if(pm)pm.value='UPI';const pstatus=document.getElementById('pStatus');if(pstatus)pstatus.textContent='Payment Status: PAID';await syncPartnerAdmin({lastAction:'PAYMENT_SUCCESS',paymentInvoice:data.invoice,paymentAmount:data.amount,paymentMethod:'UPI QR'});closeDhsPayment();showPartnerSuccess('COD Payment Successfully','Payment '+money(data.amount)+' received and saved.');activePayment=null;renderEarnings()}catch(e){toast('Payment save failed: '+e.message)}}

function showPartnerSuccess(title,text){document.getElementById('partnerSuccess')?.remove();document.body.insertAdjacentHTML('beforeend',`<div class="complete-flow" id="partnerSuccess"><div class="flow-box"><div class="flow-check">✓</div><h2>${esc(title)}</h2><p>${esc(text)}</p></div></div>`);setTimeout(()=>document.getElementById('partnerSuccess')?.remove(),3000)}

function editProfile(){showModal(`<div class="modalHead"><h3>Edit Profile</h3><button class="close" onclick="closeModal()">✕</button></div><label>Name</label><input id="en" value="${esc(first(profile,['name'],''))}"><label>Skill</label><input id="es" value="${esc(first(profile,['skill','service'],''))}"><label>Selfie</label><input id="ep" type="file" accept="image/*"><button class="btn primary full mt8" onclick="saveProfile()">Save Profile</button>`)}
async function saveProfile(){try{let patch={name:en.value,skill:es.value,updatedAt:firebase.firestore.FieldValue.serverTimestamp(),profileUpdatedBy:'partner'};if(ep.files[0])patch.selfie=await uploadFile(ep.files[0],user.uid,'profile');let c=profile?.collection||'workers',id=profile?.id||user.uid;await db.collection(c).doc(id).set(patch,{merge:true});Object.assign(profile,patch);await syncPartnerAdmin({lastAction:'UPDATE_PROFILE'});closeModal();renderProfile();toast('Profile updated and Admin synced')}catch(e){toast(e.message)}}
async function publishPartnerLocation(pos,forceOnline=null){let c=profile?.collection||'workers',id=profile?.id||user.uid;try{const now=firebase.firestore.FieldValue.serverTimestamp();const isOn=forceOnline===null?(online||profile?.online===true):forceOnline;const active=jobs.find(x=>['ACCEPTED','ON_THE_WAY','WORKING','ARRIVED'].includes(jobState(x)));const patch={latitude:pos.coords.latitude,longitude:pos.coords.longitude,lat:pos.coords.latitude,lng:pos.coords.longitude,locationUpdatedAt:now,locationPermission:'granted'};await db.collection(c).doc(id).set({...patch,lastSeen:now},{merge:true});await db.collection('partnerLocations').doc(user.uid).set({partnerId:user.uid,workerid:profile?.id||user.uid,partnerName:first(profile,['name'],user.email),partnerEmail:user.email,email:user.email,online:isOn,availability:isOn?'online':'offline',status:isOn?'online':'offline',partnerStatus:isOn?'online':'offline',currentJobId:active?.id||'',currentJobStatus:active?jobState(active):'IDLE',lastSeen:now,locationUpdatedAt:now,locationPermission:'granted',...patch},{merge:true});}catch(e){console.warn('location sync',e)}}
async function toggleOnline(){try{let next=online?'offline':'online';let c=profile?.collection||'workers',id=profile?.id||user.uid;const now=firebase.firestore.FieldValue.serverTimestamp();await db.collection(c).doc(id).set({status:next,online:next==='online',availability:next,lastSeen:now,uid:user.uid,email:user.email,workeremail:user.email,partnerStatus:next,locationSharing:next==='online'},{merge:true});online=next==='online';profile.status=next;profile.online=online;if(!online){document.getElementById('np')?.remove();document.getElementById('partnerBookingRequest')?.style.setProperty('display','none');document.querySelector('#homeMap .partnerMapOverlay')?.classList.remove('requestActive');}let publish=async pos=>publishPartnerLocation(pos,online);if(navigator.geolocation){navigator.geolocation.getCurrentPosition(publish,()=>{db.collection('partnerLocations').doc(user.uid).set({partnerId:user.uid,workerid:profile?.id||user.uid,partnerName:first(profile,['name'],user.email),email:user.email,online,availability:online?'online':'offline',status:online?'online':'offline',partnerStatus:online?'online':'offline',lastSeen:now,locationUpdatedAt:now},{merge:true})},{enableHighAccuracy:true,timeout:10000,maximumAge:5000})}else{await db.collection('partnerLocations').doc(user.uid).set({partnerId:user.uid,workerid:profile?.id||user.uid,partnerName:first(profile,['name'],user.email),email:user.email,online,availability:online?'online':'offline',status:online?'online':'offline',partnerStatus:online?'online':'offline',lastSeen:now},{merge:true})}await syncPartnerAdmin({lastAction:online?'GO_ONLINE':'GO_OFFLINE',partnerStatus:next,online});renderProfile();renderIdleAvailability();toast(online?'You are online • Ready for bookings':'You are offline • Go online to start earning')}catch(e){toast(e.message)}}
function getLocation(){if(!navigator.geolocation)return;navigator.geolocation.watchPosition(pos=>publishPartnerLocation(pos,null),()=>{}, {enableHighAccuracy:true,maximumAge:5000,timeout:15000})}
async function enableFCM(){if(!('Notification'in window)||!('serviceWorker'in navigator)||!firebase.messaging.isSupported())return;try{let perm=Notification.permission==='granted'?'granted':await Notification.requestPermission();if(perm!=='granted')return;let reg=await navigator.serviceWorker.register('firebase-messaging-sw.js');let m=firebase.messaging();fcmToken=await m.getToken({serviceWorkerRegistration:reg});if(fcmToken){let c=profile?.collection||'workers',id=profile?.id||user.uid;await db.collection(c).doc(id).set({fcmToken:fcmToken,fcmUpdatedAt:firebase.firestore.FieldValue.serverTimestamp(),uid:user.uid,email:user.email,workeremail:user.email},{merge:true})}m.onMessage(payload=>incomingNotification(payload.data||payload.notification||{}))}catch(e){console.warn(e)}}
async function incomingNotification(d){if(!online)return;playAlert();let bid=first(d,['bookingId','bookingid','bookingID','id'],'');if(bid){try{const snap=await db.collection('partnerJobs').doc(String(bid)).get();if(snap.exists){const j={id:snap.id,...snap.data()};if(!jobs.some(x=>x.id===j.id))jobs.unshift(j);recordLeadNotification(j);renderJobs();showNewBookingPopup(j);return}}catch(e){console.warn('notification booking fetch',e)}}let customer=first(d,['customerName','costumername'],'Customer'),service=first(d,['service','serviceType'],'Service');recordLeadNotification({id:'push_'+Date.now(),customer,service,address:first(d,['address','customerAddress'],'Address not available'),createdAt:new Date().toISOString(),status:'NEW'});toast('New DHS lead received')}
async function openNotifications(ev){
 // Bell toggles the panel. Android WebView can emit both touch and click; the bell handler
 // stops propagation and we intentionally use one click path only.
 if(ev){try{ev.preventDefault();ev.stopPropagation()}catch(x){}}
 const existing=document.getElementById('dhsNotificationPop');
 if(existing){
   try{existing.remove()}catch(x){}
   try{document.removeEventListener('click',window.__dhsNotifOutside,true)}catch(x){}
   return;
 }
 // Bell is always clickable once the app shell is visible; do not gate the UI on startup flags.

 const mergeLive=()=>{try{(jobs||[]).filter(j=>['NEW','PENDING_ACCEPT'].includes(jobState(j))).forEach(recordLeadNotification)}catch(e){}};
 mergeLive();
 if(user?.uid){
   const queries=[];
   try{queries.push(db.collection('partnerJobs').where('workeruid','==',user.uid).limit(50).get())}catch(e){}
   try{queries.push(db.collection('partnerJobs').where('partnerId','==',user.uid).limit(50).get())}catch(e){}
   try{queries.push(db.collection('bookings').where('workeruid','==',user.uid).limit(50).get())}catch(e){}
   try{queries.push(db.collection('bookings').where('workeremail','==',user.email).limit(50).get())}catch(e){}
   try{
     const snaps=await Promise.allSettled(queries);
     snaps.forEach(r=>{if(r.status==='fulfilled')r.value.docs.forEach(d=>{const j={id:d.id,...d.data()};if(assignedToMe(j)&&['NEW','PENDING_ACCEPT'].includes(jobState(j))){if(!jobs.some(x=>x.id===j.id))jobs.push(j);recordLeadNotification(j)}})});
     jobs.sort((a,b)=>ts(b.createdAt)-ts(a.createdAt));
   }catch(e){console.warn('bell booking fetch',e)}
 }
 updateLeadBadge();
 const live=Array.from(new Map((jobs||[]).filter(j=>['NEW','PENDING_ACCEPT'].includes(jobState(j))).map(j=>[j.id,j])).values()).sort((a,b)=>ts(b.createdAt)-ts(a.createdAt));
 const history=leadNotifications.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
 const html=live.length?live.map(j=>{const customer=first(j,['costumername','customerName','customer'],'Customer'),service=first(j,['service','serviceType'],'Service'),address=first(j,['costumerAddress','customerAddress','address'],'Address not available');return `<div class="npItem"><div class="npTitle">🔔 New Booking</div><div class="npText">${esc(customer)} ko booking partner app ko bheji · ${esc(service)}</div><div class="npText">📍 ${esc(address)}</div><div class="npMeta">Received: ${formatLeadTime(j.createdAt)}</div><div class="npActions"><button class="npAccept" onclick="closeNotificationPop();jobDecision('${esc(j.id)}','ACCEPTED')">Accept</button><button class="npReject" onclick="closeNotificationPop();jobDecision('${esc(j.id)}','REJECTED')">Reject</button></div></div>`}).join(''):(history.length?history.map(n=>`<div class="npItem" style="border-left-color:#8a96a8"><div class="npTitle">🔔 Booking</div><div class="npText">${esc(n.customer)} · ${esc(n.service)}</div><div class="npText">📍 ${esc(n.address||'Address not available')}</div><div class="npMeta">${esc(n.status||'NEW')} · ${formatLeadTime(n.createdAt)}</div></div>`).join(''):'<div class="npEmpty">No new notifications.</div>');
 const clearHistory=history.length?`<button class="npClear" onclick="leadNotifications=[];localStorage.removeItem('dhsLeadNotifications');updateLeadBadge();closeNotificationPop();setTimeout(()=>openNotifications(),0)">Clear</button>`:'';
 document.body.insertAdjacentHTML('beforeend',`<div class="notificationPop" id="dhsNotificationPop" onclick="event.stopPropagation()"><div class="npHead"><h3>Notifications</h3><button class="npClose" type="button" aria-label="Close notifications" onclick="closeNotificationPop()">×</button>${clearHistory}</div><p>New bookings and booking updates from DHS Admin.</p><div>${html}</div>${history.length?'<div class="npFoot">Notification history is saved on this partner device.</div>':''}</div>`);
 window.closeNotificationPop=()=>{const p=document.getElementById('dhsNotificationPop');if(p)p.remove();try{document.removeEventListener('click',window.__dhsNotifOutside,true)}catch(e){}};
 window.__dhsNotifOutside=(e)=>{const p=document.getElementById('dhsNotificationPop');const bell=document.getElementById('topActionBtn');if(p&&!p.contains(e.target)&&bell&&!bell.contains(e.target))window.closeNotificationPop()};
 setTimeout(()=>document.addEventListener('click',window.__dhsNotifOutside,true),0);

}
const LANGS={en:{name:'English',settings:'Settings',settingsSub:'DHS Partner App Settings',callHelp:'Call Help — DHS',slideToCall:'Slide to call DHS Help',callPolice:'Call Police',slidePolice:'Slide to call emergency police',language:'Language',bankAccount:'Bank Account',addBank:'Add your bank account for earnings',resetAll:'Reset All Data',resetSub:'Password required. Clears DHS Partner app data for this partner.',logout:'Logout',logoutSub:'Sign out from DHS Partner',resetImportant:"Reset removes only this partner's app data. A global reset must be authorized from DHS Admin/Firebase server-side.",earnings:'Earnings',totalCompleted:'Total Jobs Completed',totalEarning:'Total Earning',weekEarning:'This Week Earning',acceptedLeads:'Accepted Leads',completedJobs:'Completed Jobs'},hi:{name:'हिन्दी',settings:'सेटिंग्स',settingsSub:'DHS पार्टनर ऐप सेटिंग्स',callHelp:'DHS हेल्प कॉल',slideToCall:'DHS हेल्प के लिए स्लाइड करें',callPolice:'पुलिस को कॉल करें',slidePolice:'आपातकालीन पुलिस कॉल के लिए स्लाइड करें',language:'भाषा',bankAccount:'बैंक अकाउंट',addBank:'कमाई के लिए अपना बैंक अकाउंट जोड़ें',resetAll:'सभी डेटा रीसेट करें',resetSub:'इस पार्टनर का ऐप डेटा साफ करने के लिए पासवर्ड जरूरी है।',logout:'लॉगआउट',logoutSub:'DHS पार्टनर से साइन आउट करें',resetImportant:'रीसेट केवल इस पार्टनर का ऐप डेटा हटाता है। ग्लोबल रीसेट DHS Admin/Firebase से अधिकृत होना चाहिए।',earnings:'कमाई',totalCompleted:'कुल पूरे किए गए जॉब',totalEarning:'कुल कमाई',weekEarning:'इस सप्ताह की कमाई',acceptedLeads:'स्वीकृत लीड्स',completedJobs:'पूरे किए गए जॉब'}};
function applyLanguage(lang){lang=lang==='hi'?'hi':'en';localStorage.setItem('dhsPartnerLanguage',lang);document.querySelectorAll('[data-i18n]').forEach(e=>{const k=e.getAttribute('data-i18n');if(LANGS[lang][k])e.textContent=LANGS[lang][k]});const cur=document.getElementById('languageCurrent');if(cur)cur.textContent=LANGS[lang].name;const nav=document.querySelectorAll('.bottom button');if(nav.length){const vals=lang==='hi'?['होम','कमाई','बिल','प्रोफाइल']:['Home','Earning','Bill','Profile'];nav.forEach((b,i)=>{const span=b.querySelector('span');if(span){const icon=span.outerHTML;b.innerHTML=icon+vals[i]}})}}
function openLanguageSettings(){const current=localStorage.getItem('dhsPartnerLanguage')||'en';showModal(`<div class="modalHead"><h3>Language / भाषा</h3><button class="close" onclick="closeModal()">✕</button></div><p class="muted">Choose app language.</p><div class="langGrid"><button class="langBtn ${current==='en'?'active':''}" onclick="applyLanguage('en');closeModal()">English</button><button class="langBtn ${current==='hi'?'active':''}" onclick="applyLanguage('hi');closeModal()">हिन्दी</button></div>`)}
function openSlideCall(kind){const police=kind==='police';showModal(`<div class="modalHead"><h3>${police?'Emergency assistance':'DHS Help'}</h3><button class="close" onclick="closeModal()">✕</button></div><p class="muted">${police?'Your emergency call will open after you slide completely.':'Slide fully to call DHS Help. The phone number stays hidden.'}</p><div class="slideCallWrap"><div class="slideTrack ${police?'danger':'dhs'}"><div class="slideThumb" id="slideThumb">➜</div><span id="slideText">Slide to call</span><input class="slideRange" id="slideRange" type="range" min="0" max="100" value="0" oninput="slideCallProgress(this,'${kind}')"></div></div>`)}
function slideCallProgress(input,kind){const pct=Number(input.value||0);const track=input.parentElement,thumb=track.querySelector('.slideThumb'),text=track.querySelector('#slideText');const max=track.clientWidth-thumb.offsetWidth-10;thumb.style.left=(5+max*(pct/100))+'px';if(text)text.textContent=pct>=100?'Calling…':'Slide to call';if(pct>=100&&!window._slideCalling){window._slideCalling=true;setTimeout(()=>{closeModal();window._slideCalling=false;window.location.href=kind==='police'?'tel:112':'tel:9718448382'},180)}}
async function openBankAccount(){let data={};try{const snap=await db.collection('partnerBankAccounts').doc(user.uid).get();if(snap.exists)data=snap.data()}catch(e){data=profile?.bankAccount||{}}if(!data.accountNumber&&profile?.bankAccount)data=profile.bankAccount;showModal(`<div class="modalHead"><h3>Bank Account</h3><button class="close" onclick="closeModal()">✕</button></div><p class="muted">Add or update the bank account where DHS earnings should be paid.</p><label>Account Holder Name</label><input id="bankHolder" value="${esc(data.accountHolder||first(profile,['name'],''))}"><label>Bank Name</label><input id="bankName" value="${esc(data.bankName||'')}"><label>Account Number</label><input id="bankNumber" inputmode="numeric" value="${esc(data.accountNumber||'')}"><label>IFSC Code</label><input id="bankIfsc" value="${esc(data.ifsc||'')}"><label>UPI ID (optional)</label><input id="bankUpi" value="${esc(data.upiId||'')}"><button class="btn primary full mt8" onclick="saveBankAccount()">Save Bank Account</button>`)}
async function saveBankAccount(){const holder=document.getElementById('bankHolder')?.value.trim(),bank=document.getElementById('bankName')?.value.trim(),num=document.getElementById('bankNumber')?.value.trim(),ifsc=document.getElementById('bankIfsc')?.value.trim().toUpperCase(),upi=document.getElementById('bankUpi')?.value.trim();if(!holder||!bank||!num||!ifsc){toast('Please fill account holder, bank, account number and IFSC');return}try{const data={partnerId:user.uid,workerid:profile?.id||user.uid,accountHolder:holder,bankName:bank,accountNumber:num,ifsc,upiId:upi,updatedAt:firebase.firestore.FieldValue.serverTimestamp()};try{await db.collection('partnerBankAccounts').doc(user.uid).set(data,{merge:true})}catch(e){console.warn('partnerBankAccounts write blocked; saving to profile',e)}const c=profile?.collection||'workers',id=profile?.id||user.uid;await db.collection(c).doc(id).set({bankAccountLinked:true,bankAccount:{accountHolder:holder,bankName:bank,accountNumber:num,ifsc,upiId:upi},bankAccountUpdatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});profile.bankAccount=data;closeModal();renderBankSummary(data);toast('Bank account saved')}catch(e){toast('Bank account save failed: '+(e.message||e))}}
function renderBankSummary(data){const el=document.getElementById('bankAccountSummary');if(!el)return;if(data?.bankName&&data?.accountNumber){const n=String(data.accountNumber);el.textContent=data.bankName+' • A/C ****'+n.slice(-4)+(data.ifsc?' • '+data.ifsc:'')}else el.textContent=(localStorage.getItem('dhsPartnerLanguage')==='hi'?'कमाई के लिए अपना बैंक अकाउंट जोड़ें':'Add your bank account for earnings')}
async function loadPartnerSettings(){applyLanguage(localStorage.getItem('dhsPartnerLanguage')||'en');renderBankSummary(profile?.bankAccount);const el=document.getElementById('resetPasswordAction');if(!el||!user)return;try{let configured=profile?.resetPasswordConfigured===true;try{const snap=await db.collection('partnerSettings').doc(user.uid).get();configured=configured||(snap.exists&&snap.data()?.resetPasswordConfigured===true)}catch(e){console.warn('partnerSettings read blocked; using profile flag',e)}el.innerHTML=configured?'':'<button class="settingsItem help" onclick="setResetPasswordOnce()"><svg viewBox="0 0 24 24"><path d="M12 2a4 4 0 0 0-4 4v3h8V6a4 4 0 0 0-4-4Z"/><rect x="5" y="9" width="14" height="12" rx="2"/><path d="M12 13v4"/></svg><span class="siText"><b>Set Reset Password</b><small>Set once. After saving, this option is removed.</small></span><span class="chev">›</span></button>'}catch(e){console.warn('partner settings',e)}}
async function setResetPasswordOnce(){showModal(`<div class="modalHead"><h3>Set Reset Password</h3><button class="close" onclick="closeModal()">✕</button></div><p class="muted">This changes the Firebase login password. Set it once here; future password changes can be done through Firebase password reset.</p><label>Current Firebase Password</label><input id="currentResetPass" type="password" autocomplete="current-password"><label>New Password</label><input id="newResetPass" type="password" autocomplete="new-password"><label>Confirm New Password</label><input id="confirmResetPass" type="password" autocomplete="new-password"><button class="btn primary full mt8" onclick="saveResetPasswordOnce()">Set Password</button>`)}
async function saveResetPasswordOnce(){const cur=document.getElementById('currentResetPass')?.value,newP=document.getElementById('newResetPass')?.value,conf=document.getElementById('confirmResetPass')?.value;if(!cur||!newP||!conf){toast('All password fields are required');return}if(newP.length<6){toast('Password must be at least 6 characters');return}if(newP!==conf){toast('New passwords do not match');return}try{const credential=firebase.auth.EmailAuthProvider.credential(user.email,cur);await auth.currentUser.reauthenticateWithCredential(credential);await auth.currentUser.updatePassword(newP);try{await db.collection('partnerSettings').doc(user.uid).set({resetPasswordConfigured:true,resetPasswordConfiguredAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true})}catch(e){console.warn('partnerSettings write blocked; using profile flag',e)}const c=profile?.collection||'workers',id=profile?.id||user.uid;await db.collection(c).doc(id).set({resetPasswordConfigured:true,resetPasswordConfiguredAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});profile.resetPasswordConfigured=true;closeModal();await loadPartnerSettings();toast('Reset password set successfully')}catch(e){toast('Password update failed: '+(e.message||e))}}
async function resetData(){let configured=profile?.resetPasswordConfigured===true;try{const settings=await db.collection('partnerSettings').doc(user.uid).get();configured=configured||(settings.exists&&settings.data()?.resetPasswordConfigured===true)}catch(e){console.warn('partnerSettings read blocked; using profile flag',e)}if(!configured){toast('Set the reset password first');await loadPartnerSettings();return}showModal(`<div class="modalHead"><h3>Reset All Data</h3><button class="close" onclick="closeModal()">✕</button></div><p class="dangerText">This clears this partner's bookings, bills, payments and activity. Firebase login account stays active.</p><label>Firebase Password</label><input id="resetPassword" type="password" autocomplete="current-password"><button class="btn danger full mt8" onclick="confirmResetData()">Reset Data</button>`)}
async function confirmResetData(){const p=document.getElementById('resetPassword')?.value;if(!p){toast('Password required');return}const btn=document.querySelector('#modal .btn.danger');if(btn){btn.disabled=true;btn.textContent='Resetting…'}try{const credential=firebase.auth.EmailAuthProvider.credential(user.email,p);await auth.currentUser.reauthenticateWithCredential(credential);let batch=db.batch();let qs=await db.collection('partnerJobs').where('workeruid','==',user.uid).get();qs.docs.forEach(d=>batch.delete(d.ref));let bs=await db.collection('bills').where('partnerId','==',user.uid).get();bs.docs.forEach(d=>batch.delete(d.ref));let ps=await db.collection('payments').where('partnerId','==',user.uid).get();ps.docs.forEach(d=>batch.delete(d.ref));let acts=await db.collection('partnerActivity').where('partnerId','==',user.uid).get();acts.docs.forEach(d=>batch.delete(d.ref));await batch.commit();await syncPartnerAdmin({status:'offline',online:false,availability:'offline',lastAction:'RESET_DATA',resetAt:firebase.firestore.FieldValue.serverTimestamp()});online=false;if(profile){profile.status='offline';profile.online=false}closeModal();renderProfile();toast('Partner data reset and Admin updated')}catch(e){if(btn){btn.disabled=false;btn.textContent='Reset Data'}toast('Reset failed: '+(e.message||e))}}
function showModal(inner){closeModal();document.body.insertAdjacentHTML('beforeend',`<div class="modalBack" id="modal"><div class="modal">${inner}</div></div>`)}function closeModal(){document.getElementById('modal')?.remove()}
async function gate(u){
 if(!u){profile=null;login();return}
 const safeGet=async(fn,label)=>{try{return await fn()}catch(e){console.warn('DHS Partner '+label+' lookup skipped:',e);return null}};
 try{
  profile=null;
  const email=(u.email||'').toLowerCase();
  // Try every supported profile source independently. A Firestore permission
  // problem in one collection must NOT block the whole Partner app.
  let w=await safeGet(()=>db.collection('workers').doc(u.uid).get(),'workers/uid');
  if(w?.exists){profile={id:w.id,collection:'workers',...w.data()};}
  if(!profile){
    let snap=await safeGet(()=>db.collection('workers').where('workeremail','==',email).limit(1).get(),'workers/workeremail');
    if(snap?.empty) snap=await safeGet(()=>db.collection('workers').where('email','==',email).limit(1).get(),'workers/email');
    if(snap && !snap.empty){const d=snap.docs[0];profile={id:d.id,collection:'workers',...d.data()};}
  }
  if(!profile){
    const snap=await safeGet(()=>db.collection('partners').where('email','==',email).limit(1).get(),'partners/email');
    if(snap && !snap.empty){const d=snap.docs[0];profile={id:d.id,collection:'partners',...d.data()};}
  }
  if(!profile){
    const reg=await safeGet(()=>db.collection('partnerRegistrations').doc(u.uid).get(),'partnerRegistrations');
    if(reg?.exists){
      const d=reg.data(),st=String(d.status||d.partnerStatus||d.registrationStatus||'').toUpperCase();
      if(d.approved===true||['APPROVED','JOINED','ACTIVE'].includes(st)){profile={id:u.uid,collection:'partnerRegistrations',...d};}
      else if(st==='PENDING_REVIEW'){showWaiting(u.email,u.uid);return;}
      else if(st==='REJECTED'){showWaiting(u.email,u.uid);return;}
    }
  }
  if(!profile){
    const app=await safeGet(()=>db.collection('partnerApplications').doc(u.uid).get(),'partnerApplications');
    if(app?.exists){
      const d=app.data(),st=String(d.status||d.partnerStatus||d.registrationStatus||'').toUpperCase();
      if(d.approved===true||['APPROVED','JOINED','ACTIVE'].includes(st)){profile={id:u.uid,collection:'partnerApplications',...d};}
      else if(st==='PENDING_REVIEW'){showWaiting(u.email,u.uid);return;}
    }
  }
  if(profile){
    const st=String(profile.status||'').toUpperCase();
    if(profile.approved===false || st==='REJECTED' || st==='DISABLED'){
      await auth.signOut();
      document.getElementById('root').innerHTML='<div class="wait"><div class="waitbox glass"><div class="big">❌</div><h2>Partner Access Blocked</h2><p>Admin has not approved or has disabled this partner account.</p><button class="btn white full" onclick="login()">Back to Login</button></div></div>';
      return;
    }
    closeModal?.();
    shell();
    window.__dhsAppReady=true;
    return;
  }
  // Auth is valid even if the profile document is temporarily unavailable.
  // Open the app with a safe local profile fallback instead of showing a
  // blocking "Unable to load DHS Partner profile" screen.
  profile={id:u.uid,collection:'workers',uid:u.uid,email:u.email||'',name:u.displayName||((u.email||'DHS Partner').split('@')[0]),skill:'Partner',status:'offline',online:false};
  console.warn('DHS Partner profile document unavailable; using auth fallback. Check Firebase workers/partners rules or Admin profile mapping.');
  closeModal?.();
  shell();
  window.__dhsAppReady=true;
 }catch(e){
  console.warn('DHS Partner startup recovered from profile error:',e);
  // Never block an authenticated partner because of a profile read error.
  profile={id:u.uid,collection:'workers',uid:u.uid,email:u.email||'',name:u.displayName||((u.email||'DHS Partner').split('@')[0]),skill:'Partner',status:'offline',online:false};
  closeModal?.();
  shell();
  window.__dhsAppReady=true;
 }
}
auth.onAuthStateChanged(async u=>{
  document.getElementById('signinPop')?.remove();
  user=u;
  if(u){gate(u);} else {login();}
});
document.addEventListener('focusin',e=>{if(e.target?.closest?.('.bill-editor'))document.body.classList.add('billTyping')});document.addEventListener('focusout',()=>{setTimeout(()=>{if(!document.querySelector('.bill-editor input:focus,.bill-editor textarea:focus,.bill-editor select:focus'))document.body.classList.remove('billTyping')},80)});document.addEventListener('click',e=>{if(e.target?.closest?.('.bill-editor')){if(e.target.matches('input,textarea,select'))document.body.classList.add('billTyping')}else if(document.activeElement?.closest?.('.bill-editor'))document.body.classList.add('billTyping')});

(function(){
 let startY=0,startX=0,pulling=false,refreshing=false;
 const threshold=85;
 function overlay(show){const e=document.getElementById('dhsPullRefresh');if(!e)return;e.classList.toggle('show',show);e.setAttribute('aria-hidden',show?'false':'true');}
 function canPull(){return !refreshing && window.scrollY<=2 && !document.querySelector('.modalBack');}
 document.addEventListener('touchstart',function(e){if(!canPull()||!e.touches[0])return;startY=e.touches[0].clientY;startX=e.touches[0].clientX;pulling=true;},{passive:true});
 document.addEventListener('touchmove',function(e){if(!pulling||!e.touches[0])return;const dy=e.touches[0].clientY-startY,dx=e.touches[0].clientX-startX;if(dy<0||Math.abs(dx)>Math.abs(dy)*1.15){pulling=false;return;}if(dy>15)e.preventDefault();},{passive:false});
 async function performDhsRefresh(){
   // IMPORTANT: this is an in-app data refresh. Do NOT reload the WebView/document.
   // Reloading caused the DHS splash/blue screen and reset the visible screen.
   try{
     if(!user){return;}
     // Keep the currently visible page exactly as-is. Refresh only Firebase-backed data.
     try{listenJobs();}catch(e){console.warn('refresh jobs',e)}
     try{listenBills();}catch(e){console.warn('refresh bills',e)}
     try{listenPayments();}catch(e){console.warn('refresh payments',e)}
     try{await loadPartnerSettings();}catch(e){console.warn('refresh settings',e)}
     try{renderProfile();renderIdleAvailability();updateTopAction();updateLeadBadge();}catch(e){console.warn('refresh render',e)}
     // Re-publish the current location without changing the partner's online state.
     if(navigator.geolocation && online){
       navigator.geolocation.getCurrentPosition(pos=>publishPartnerLocation(pos, true),()=>{}, {enableHighAccuracy:true,timeout:10000,maximumAge:5000});
     }
   }finally{
     setTimeout(()=>{refreshing=false;overlay(false);},120);
   }
 }
 function startDhsRefresh(){
   if(refreshing)return;
   refreshing=true;
   overlay(true);
   // Keep the existing refresh glass/popup, but refresh data in-place instead of reloading.
   setTimeout(()=>{performDhsRefresh();},700);
 }
 document.addEventListener('touchend',function(e){
   if(!pulling)return;
   pulling=false;
   const dy=(e.changedTouches[0]?.clientY||0)-startY;
   if(dy<threshold)return;
   startDhsRefresh();
 },{passive:true});
 window.dhsManualRefresh=function(){startDhsRefresh();};
})();


/* Hard override: the Home live card must show rotating tools only while Online. */
(function(){
  const oldSet=window.setHomeWaitingState;
  window.setHomeWaitingState=function(waiting=true){
    if(oldSet)oldSet(waiting);
    const map=document.getElementById('homeMap');
    if(map && waiting)map.classList.add('idleWaiting');
    const orbit=document.getElementById('idleToolsOrbit');
    if(orbit)orbit.classList.toggle('online',!!online);
  };
})();

let dhsChatUnsub=null,dhsRecording=null,dhsRecordChunks=[],dhsRecordStream=null;
function closeDhsHelpChat(){
  try{dhsChatUnsub?.();}catch(e){} dhsChatUnsub=null;
  try{dhsRecording?.stop();}catch(e){} dhsRecording=null;
  try{dhsRecordStream?.getTracks?.().forEach(t=>t.stop());}catch(e){} dhsRecordStream=null;
  document.getElementById('dhsChatOverlay')?.remove();
  document.body.classList.remove('dhs-chat-open');
}
function openDhsHelpChat(){
  closeDhsHelpChat();
  document.body.classList.add('dhs-chat-open');
  document.body.insertAdjacentHTML('beforeend',`<div class="dhsChatOverlay" id="dhsChatOverlay">
    <div class="dhsChatHead"><button class="dhsChatBack" onclick="closeDhsHelpChat()" aria-label="Back"><svg width="25" height="25" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg></button><img class="dhsChatAvatar" src="images/dhs-help-team-icon.png" alt="DHS Help Team"><div class="dhsChatHeadText"><b>Chat DHS Help Team</b><small><span class="dhsChatStatus"></span> DHS Support • Online</small></div><button class="dhsChatBack dhsChatMenu" onclick="openDhsChatInfo()" aria-label="More">⋮</button></div>
    <div class="dhsChatBody" id="dhsChatBody"><div class="dhsChatEmpty"><b>DHS Help Team</b>Loading your support chat…</div></div>
    <div class="dhsChatRecordLabel" id="dhsChatRecordLabel">Recording voice message… tap microphone again to stop</div>
    <div class="dhsChatComposer"><textarea id="dhsChatInput" class="dhsChatInput" rows="1" placeholder="Type a message…" oninput="dhsChatAutoGrow(this)" onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendDhsChatMessage()}"></textarea><button class="dhsChatIconBtn dhsChatMic" id="dhsChatMic" onclick="toggleDhsVoiceRecording()" aria-label="Voice message"><svg width="21" height="21" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a1 1 0 0 1 2 0 4.5 4.5 0 0 0 9 0 1 1 0 1 1 2 0 6.5 6.5 0 0 1-5.5 6.42V20h2a1 1 0 1 1 0 2H9a1 1 0 1 1 0-2h2v-2.58A6.5 6.5 0 0 1 5.5 11Z"/></svg></button><button class="dhsChatIconBtn dhsChatSend" onclick="sendDhsChatMessage()" aria-label="Send"><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg></button></div>
  </div>`);
  listenDhsHelpChat();
  setTimeout(()=>document.getElementById('dhsChatInput')?.focus(),250);
}
function dhsChatAutoGrow(el){el.style.height='42px';el.style.height=Math.min(el.scrollHeight,110)+'px'}
function openDhsChatInfo(){showModal('<div class="modalHead"><h3>DHS Help Team</h3><button class="close" onclick="closeModal()">✕</button></div><p class="muted">Messages sent here are linked to your DHS Partner account. Voice messages use your phone microphone permission.</p>')}
function listenDhsHelpChat(){
  const body=document.getElementById('dhsChatBody');if(!body||!user?.uid)return;try{dhsChatUnsub?.()}catch(e){}
  const renderRows=docs=>{const rows=docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>chatTs(a.createdAt)-chatTs(b.createdAt));body.innerHTML=rows.length?rows.map(renderDhsChatMessage).join(''):`<div class="dhsChatEmpty"><b>Chat DHS Help Team</b>Hello! How can we help you today? 👋</div>`;body.scrollTop=body.scrollHeight};
  dhsChatUnsub=db.collection('partnerHelpChats').where('partnerId','==',user.uid).onSnapshot(s=>renderRows(s.docs),e=>{
    body.innerHTML='<div class="dhsChatEmpty"><b>DHS Help Team</b>Chat access blocked. Firebase Firestore Rules me partnerHelpChats ka partner access enable karein.</div>';
    console.warn('DHS chat listener failed',e);
  });
}
function chatTs(v){if(v?.toDate)return v.toDate().getTime();if(v?.seconds)return Number(v.seconds)*1000;const t=Date.parse(v||'');return isNaN(t)?0:t}
function renderDhsChatMessage(m){
  const mine=String(m.senderId||m.partnerId||'')===String(user?.uid||'') && String(m.senderType||'partner').toLowerCase()!=='support';
  const type=String(m.type||'text').toLowerCase(),time=chatTs(m.createdAt)?new Date(chatTs(m.createdAt)).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}):'';
  let content='';
  if(type==='audio'&&(m.audioUrl||m.url))content=`<audio class="dhsChatAudio" controls src="${esc(m.audioUrl||m.url)}"></audio>`;
  else if(type==='image'&&(m.fileUrl||m.url))content=`<img class="dhsChatImage" src="${esc(m.fileUrl||m.url)}" alt="Attachment">`;
  else content=esc(m.text||'');
  return `<div class="dhsChatMsg ${mine?'partner':'support'}">${content}<span class="dhsChatTime">${esc(time)}${mine?' ✓✓':''}</span></div>`;
}
async function sendDhsChatMessage(){
  const input=document.getElementById('dhsChatInput'),text=input?.value?.trim();
  if(!text||!user?.uid){if(!user?.uid)toast('Please login again');return}
  const body=document.getElementById('dhsChatBody');
  const sendBtn=document.querySelector('.dhsChatSend');
  if(sendBtn)sendBtn.disabled=true;
  const temp=document.createElement('div');temp.className='dhsChatMsg partner';temp.innerHTML=esc(text)+'<span class="dhsChatTime">sending…</span>';body?.appendChild(temp);if(body)body.scrollTop=body.scrollHeight;
  const payload={partnerId:user.uid,partnerEmail:user.email||'',partnerName:first(profile,['name'],user.email||'DHS Partner'),senderId:user.uid,senderType:'partner',type:'text',text,createdAt:firebase.firestore.FieldValue.serverTimestamp()};
  try{
    input.value='';dhsChatAutoGrow(input);
    await db.collection('partnerHelpChats').add(payload);
    temp.remove();
  }catch(e){
    temp.remove();input.value=text;dhsChatAutoGrow(input);
    const code=e?.code||'';
    const msg=code==='permission-denied'?'Chat permission denied. Firebase Firestore Rules me partnerHelpChats access allow karein.':(e?.message||'Message send failed.');
    toast(msg);
    console.warn('DHS chat send failed',e);
  }finally{if(sendBtn)sendBtn.disabled=false;input?.focus()}
}
// Expose chat handlers to inline HTML onclick/onkeydown handlers inside Android WebView.
window.closeDhsHelpChat=closeDhsHelpChat;
window.openDhsHelpChat=openDhsHelpChat;
window.dhsChatAutoGrow=dhsChatAutoGrow;
window.openDhsChatInfo=openDhsChatInfo;
window.listenDhsHelpChat=listenDhsHelpChat;
window.renderDhsChatMessage=renderDhsChatMessage;
window.sendDhsChatMessage=sendDhsChatMessage;
window.toggleDhsVoiceRecording=toggleDhsVoiceRecording;

async function toggleDhsVoiceRecording(){
  const btn=document.getElementById('dhsChatMic'),label=document.getElementById('dhsChatRecordLabel');if(!btn)return;
  if(dhsRecording){try{dhsRecording.stop();}catch(e){}return}
  if(!navigator.mediaDevices?.getUserMedia||typeof MediaRecorder==='undefined'){toast('Voice recording is not supported on this phone');return}
  try{
    dhsRecordStream=await navigator.mediaDevices.getUserMedia({audio:true});
    dhsRecordChunks=[];dhsRecording=new MediaRecorder(dhsRecordStream);
    dhsRecording.ondataavailable=e=>{if(e.data?.size)dhsRecordChunks.push(e.data)};
    dhsRecording.onstop=async()=>{
      btn.classList.remove('recording');if(label)label.classList.remove('show');
      const rec=dhsRecording;dhsRecording=null;try{dhsRecordStream?.getTracks?.().forEach(t=>t.stop())}catch(e){}dhsRecordStream=null;
      const blob=new Blob(dhsRecordChunks,{type:rec?.mimeType||'audio/webm'});dhsRecordChunks=[];
      if(blob.size<500){toast('Voice message is too short');return}
      try{
        const ext=(blob.type||'').includes('mp4')?'m4a':(blob.type||'').includes('ogg')?'ogg':'webm';
        const ref=storage.ref('partnerHelpChats/'+user.uid+'/voice_'+Date.now()+'.'+ext);await ref.put(blob,{contentType:blob.type||'audio/webm',customMetadata:{uploadedBy:user.uid,uploadType:'helpVoice'}});const url=await ref.getDownloadURL();
        await db.collection('partnerHelpChats').add({partnerId:user.uid,partnerEmail:user.email||'',partnerName:first(profile,['name'],user.email||'DHS Partner'),senderId:user.uid,senderType:'partner',type:'audio',audioUrl:url,createdAt:firebase.firestore.FieldValue.serverTimestamp()});
      }catch(e){toast('Voice message upload failed: '+(e.message||e))}
    };
    dhsRecording.start();btn.classList.add('recording');if(label)label.classList.add('show');
  }catch(e){toast('Microphone permission required for voice chat')}
}
