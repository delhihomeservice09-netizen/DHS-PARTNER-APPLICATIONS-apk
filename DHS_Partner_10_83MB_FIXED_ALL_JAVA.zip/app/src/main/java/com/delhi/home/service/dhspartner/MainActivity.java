package com.delhihomeservice.dhspartner;

import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.Color;import android.net.Uri;import android.os.*;import android.view.*;import android.widget.*;import androidx.core.app.ActivityCompat;import androidx.core.content.ContextCompat;import com.google.firebase.auth.*;import com.google.firebase.firestore.*;import com.google.firebase.messaging.FirebaseMessaging;import java.util.*;

public class MainActivity extends Activity{
 FirebaseAuth auth; FirebaseFirestore db; FirebaseUser user; DocumentSnapshot profile; ListenerRegistration bookingListener; boolean online=false; LinearLayout body; TextView title; final int CALL=41; int navy=Color.rgb(6,27,70), orange=Color.rgb(255,138,36); 
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(navy);getWindow().setNavigationBarColor(navy);auth=FirebaseAuth.getInstance();
 if(Build.VERSION.SDK_INT>=34){
    NotificationManager nm=getSystemService(NotificationManager.class);
    if(nm!=null && !nm.canUseFullScreenIntent()){
        try{
            Intent fsi=new Intent(
                android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT
            );
            fsi.setData(Uri.parse("package:"+getPackageName()));
            startActivity(fsi);
        }catch(Exception ignored){}
    }
}
 db=FirebaseFirestore.getInstance(); if(Build.VERSION.SDK_INT>=33) ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},88); if(auth.getCurrentUser()==null)showLogin();else loadProfile();}
 TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.DKGRAY);t.setPadding(20,14,20,14);return t;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);return b;}
 void shell(String name){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(246,248,252)); LinearLayout head=new LinearLayout(this);head.setPadding(18,18,18,8);head.setGravity(Gravity.CENTER_VERTICAL);title=tv(name,22);title.setTextColor(navy);title.setTypeface(null,1);head.addView(title,new LinearLayout.LayoutParams(0,-2,1));root.addView(head); ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(12,8,12,90);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);String[] n={"Home","Earnings","Bill","Profile"};for(String x:n){Button q=btn(x);q.setOnClickListener(v->{if(x.equals("Home"))home();if(x.equals("Earnings"))earnings();if(x.equals("Bill"))bills();if(x.equals("Profile"))profileScreen();});nav.addView(q,new LinearLayout.LayoutParams(0,58,1));}root.addView(nav);setContentView(root);}
 void showLogin(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(28,80,28,28);l.setBackgroundColor(Color.WHITE);TextView h=tv("DHS Partner",30);h.setTextColor(navy);h.setTypeface(null,1);l.addView(h);l.addView(tv("Trusted Professionals for a Better Home & Office",14));EditText e=new EditText(this);e.setHint("Email");EditText p=new EditText(this);p.setHint("Password");p.setInputType(129);l.addView(e);l.addView(p);Button login=btn("Login");l.addView(login);Button reg=btn("New Partner Registration");l.addView(reg);login.setOnClickListener(v->auth.signInWithEmailAndPassword(e.getText().toString().trim(),p.getText().toString()).addOnSuccessListener(x->loadProfile()).addOnFailureListener(x->toast(x.getMessage())));reg.setOnClickListener(v->registerDialog());setContentView(l);}
 void registerDialog(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText n=new EditText(this);n.setHint("Full name");EditText e=new EditText(this);e.setHint("Email");EditText p=new EditText(this);p.setHint("Password");EditText s=new EditText(this);s.setHint("Skill (Plumber / Electrician / AC / Painter)");l.addView(n);l.addView(e);l.addView(p);l.addView(s);new AlertDialog.Builder(this).setTitle("New Partner Registration").setView(l).setPositiveButton("Register",(d,w)->auth.createUserWithEmailAndPassword(e.getText().toString().trim(),p.getText().toString()).addOnSuccessListener(r->{String uid=r.getUser().getUid();Map<String,Object> m=new HashMap<>();m.put("name",n.getText().toString());m.put("email",e.getText().toString());m.put("uid",uid);m.put("skill",s.getText().toString());m.put("status","pending");m.put("approved",false);m.put("createdAt",FieldValue.serverTimestamp());db.collection("workers").document(uid).set(m).addOnSuccessListener(z->{toast("Registration submitted. Admin approval required.");auth.signOut();showLogin();});}).addOnFailureListener(x->toast(x.getMessage()))).setNegativeButton("Cancel",null).show();}
 void loadProfile(){user=auth.getCurrentUser();db.collection("workers").document(user.getUid()).get().addOnSuccessListener(x->{if(!x.exists()){toast("Partner Profile Not Found");auth.signOut();showLogin();return;}profile=x;if(!Boolean.TRUE.equals(x.getBoolean("approved")) && !"active".equalsIgnoreCase(x.getString("status"))){toast("Your partner account is waiting for admin approval");auth.signOut();showLogin();return;}startBookingListener();home();FirebaseMessaging.getInstance().getToken().addOnSuccessListener(t->db.collection("workers").document(user.getUid()).set(Collections.singletonMap("fcmToken",t),SetOptions.merge()));}).addOnFailureListener(x->toast("Profile error: "+x.getMessage()));}
 void home(){shell("DHS Partner");String name=profile==null?"Partner":String.valueOf(profile.getString("name"));body.addView(tv("Hello, "+name,24));body.addView(tv("Trusted Professionals for a Better Home & Office",14));Button on=btn(online?"● ONLINE — Ready for bookings":"○ OFFLINE — Tap to go online");on.setOnClickListener(v->toggleOnline(on));body.addView(on);Button leads=btn("View New Leads");leads.setOnClickListener(v->showJobs("NEW"));body.addView(leads);TextView info=tv("New bookings will appear as an accept/reject alert even when another app is open (subject to Android notification/full-screen permissions).",13);body.addView(info);}
 void toggleOnline(Button b){online=!online;Map<String,Object> m=new HashMap<>();m.put("online",online);m.put("status",online?"online":"offline");m.put("availability",online?"online":"offline");m.put("partnerStatus",online?"online":"offline");m.put("lastSeen",FieldValue.serverTimestamp());db.collection("workers").document(user.getUid()).set(m,SetOptions.merge()).addOnSuccessListener(x->{if(online){startService(new Intent(this,OnlineService.class));toast("You are online");}else{stopService(new Intent(this,OnlineService.class));toast("You are offline");}home();}).addOnFailureListener(x->{online=!online;toast(x.getMessage());});}
 void startBookingListener(){
    if(bookingListener!=null){
        bookingListener.remove();
    }

    String uid=user.getUid();

    bookingListener =
            db.collection("bookings")
                    .whereEqualTo("workeruid",uid)
                    .addSnapshotListener((s,e)->{
                        // Firestore listener sirf booking data sync karega.
                        // Popup FCM se aayega.
                    });
}

 Set<String> alerted=new HashSet<>();

void handleBookings(QuerySnapshot s){
    // Booking popup yahan se nahi khulega.
    // Popup DhsMessagingService ke FCM Full-Screen Intent se aayega.
}
 String safe(DocumentSnapshot d,String...ks){for(String k:ks){String v=d.getString(k);if(v!=null&&!v.trim().isEmpty())return v;}return "";}
 void showJobs(String status){body.removeAllViews();body.addView(tv("Bookings",23));db.collection("bookings").whereEqualTo("workeruid",user.getUid()).get().addOnSuccessListener(s->{for(DocumentSnapshot d:s){String st=safe(d,"status");if(status.equals("NEW")&&!(("NEW".equalsIgnoreCase(st)||"PENDING_ACCEPT".equalsIgnoreCase(st))))continue;card(d);}});}
 void card(DocumentSnapshot d){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(14,14,14,14);c.setBackgroundColor(Color.WHITE);c.addView(tv(safe(d,"customerName","name","customer"),19));c.addView(tv(safe(d,"service","skill"),15));c.addView(tv(safe(d,"address","location"),14));Button a=btn("Open Booking");a.setOnClickListener(v->openAlert(d));c.addView(a);body.addView(c,new LinearLayout.LayoutParams(-1,-2));Space sp=new Space(this);body.addView(sp,new LinearLayout.LayoutParams(1,10));}
 void openAlert(DocumentSnapshot d){Intent i=new Intent(this,BookingAlertActivity.class);i.putExtra("bookingId",d.getId());i.putExtra("customer",safe(d,"customerName","name","customer"));i.putExtra("service",safe(d,"service","skill"));i.putExtra("address",safe(d,"address","location"));i.putExtra("phone",safe(d,"phone","customerPhone","customerPhoneNumber"));startActivity(i);}
 void earnings(){shell("Earnings");db.collection("bookings").whereEqualTo("workeruid",user.getUid()).get().addOnSuccessListener(s->{int done=0;double earn=0;for(DocumentSnapshot d:s){if("COMPLETED".equalsIgnoreCase(safe(d,"status"))){done++;Object a=d.get("amount");if(a instanceof Number)earn+=((Number)a).doubleValue();}}body.addView(tv("Total Jobs Completed\n"+done,21));body.addView(tv("Total Earning\n₹"+String.format(Locale.US,"%.0f",earn),21));body.addView(tv("This Week Earning\nCalculated from your completed jobs",17));});}
 void bills(){shell("Create Bill");body.addView(tv("Generate customer bill after completing a job.",16));Button cash=btn("💵 Pay Cash");Button qr=btn("▣ Pay QR");body.addView(cash);body.addView(qr);cash.setOnClickListener(v->{tin();toast("Cash payment recorded after bill details are saved");});qr.setOnClickListener(v->{tin();toast("QR payment screen");});}
 void profileScreen(){shell("Profile");body.addView(tv("Partner\n"+safe(profile,"name","email")+"\n"+safe(profile,"skill"),20));Button logout=btn("Logout");logout.setOnClickListener(v->{if(bookingListener!=null)bookingListener.remove();stopService(new Intent(this,OnlineService.class));auth.signOut();showLogin();});body.addView(logout);Button help=btn("Call DHS Help — 97184 48382");help.setOnClickListener(v->call("9718448382"));body.addView(help);Button reset=btn("Reset All Data");reset.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Reset All Data").setMessage("Delete partner job/payment data? Authentication account stays active.").setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->toast("Reset requires your secured Firebase rules/admin flow." )).show());body.addView(reset);}
 void call(String n){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CALL_PHONE},CALL);return;}try{startActivity(new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+n)));}catch(Exception e){startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+n)));}}
 void tin(){try{android.media.MediaPlayer m=android.media.MediaPlayer.create(this,getResources().getIdentifier("dhs_booking_alert","raw",getPackageName()));if(m!=null){m.setVolume(.7f,.7f);m.setOnCompletionListener(android.media.MediaPlayer::release);m.start();}}catch(Exception ignored){}}
 void toast(String s){Toast.makeText(this,s==null?"":s,Toast.LENGTH_SHORT).show();}
 @Override protected void onDestroy(){if(bookingListener!=null)bookingListener.remove();super.onDestroy();}
}
