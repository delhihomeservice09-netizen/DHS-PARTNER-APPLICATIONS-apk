package com.delhihomeservice.dhspartner;
import android.app.*;import android.content.*;import android.os.*;import androidx.core.app.NotificationCompat;import com.google.firebase.auth.FirebaseAuth;import com.google.firebase.firestore.*;import java.util.*;
public class OnlineService extends Service{
 static final int ID=8208; @Override public void onCreate(){super.onCreate();String ch="dhs_online";if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(ch,"DHS Partner Online",NotificationManager.IMPORTANCE_LOW);c.setShowBadge(false);c.setDescription("Persistent DHS Partner online status");getSystemService(NotificationManager.class).createNotificationChannel(c);}NotificationCompat.Builder b=new NotificationCompat.Builder(this,ch).setSmallIcon(com.delhihomeservice.dhspartner.R.mipmap.ic_launcher).setContentTitle("DHS Partner").setContentText("You are online • Ready for bookings").setOngoing(true).setAutoCancel(false).setCategory(NotificationCompat.CATEGORY_SERVICE).setPriority(NotificationCompat.PRIORITY_LOW);startForeground(ID,b.build());}
 @Override public int onStartCommand(Intent i,int flags,int startId){return START_STICKY;}
 @Override public IBinder onBind(Intent i){return null;}
}
